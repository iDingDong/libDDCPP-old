// standard\DDError.hpp
#ifndef _DDERROR_HPP
#	define _DDERROR_HPP 1



#	include "bits/DD_AllocationFailure.hpp"



#endif
