// standard\DDGlobal.hpp
#ifndef _DDGLOBAL_HPP
#	define _DDGLOBAL_HPP 1



#	include "bits/DD_Nil.hpp"



#endif
