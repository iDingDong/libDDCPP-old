// standard/bits/DDMeta.hpp
#ifndef _DD_META_HPP
#	define _DD_META_HPP



#	include "bits/DD_NestedTypeCheck.hpp"



#endif
