// DDLogistics.hpp
#ifndef _DDLOGISTICS_
 #define _DDLOGISTICS_


 #include <DDGlobal.hpp>



DD_BEGIN
struct DDObject {
    
    
    ValidityType marked = false;
}



class DDGarbageCollect {
    
    
    
    
}



DD_END



#endif