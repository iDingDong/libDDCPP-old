#ifndef _DDLOGGER_
 #define _DDLOGGER_



 #include "DDGlobal.hpp"
 #include <fstream>



class DDLogger {
    public:
    DDLogger();
    DDErrorType log_test();
    
    private:
    
}



#endif