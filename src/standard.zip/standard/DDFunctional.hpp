// standard/DDFunctional.hpp
#ifndef _DDFUNCTIONAL_HPP
#	define _DDFUNCTIONAL_HPP 1



#	include "bits/DD_Functor.hpp"



#endif