// standard/DDCompatibility.hpp
#ifndef _DDCOMPATIBILITY_HPP
#	define _DDCOMPATIBILITY_HPP 1



#	include "bits/DD_compatibility_definitions.hpp"
#	include "bits/DD_CompatStlIterator.hpp"
#	include "bits/DD_CompatStlContainer.hpp"



#endif
