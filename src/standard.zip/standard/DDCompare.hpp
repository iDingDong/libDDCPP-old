// standard\DDCompare.hpp
#ifndef _DDCOMPARE_HPP
#	define _DDCOMPARE_HPP 1



#	include "bits/DD_relationship_operators.hpp"



#endif
