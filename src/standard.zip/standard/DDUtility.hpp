// standard/DDUtility.hpp
#ifndef _DDUTILITY_HPP
#	define _DDUTILITY_HPP 1



#	if __cplusplus >= 201103L
#		include "bits/DD_Tuple.hpp"
#	else
#		include "bits/DD_Pair.hpp"
#	endif
#	include "bits/DD_swap.hpp"



#endif