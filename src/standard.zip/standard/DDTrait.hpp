// standard\DDTrait.hpp 
#ifndef _DDTRAIT_HPP
#	define _DDTRAIT_HPP 1



#	include "bits/DD_Trait.hpp"
#	include "bits/DD_Conditional.hpp"
#	if __cplusplus < 201103L
#		include "bits/DD_Or.hpp"
#		include "bits/DD_And.hpp"
#	endif



#endif
