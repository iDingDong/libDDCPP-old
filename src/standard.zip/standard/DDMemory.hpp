// standard/DDMemory.hpp
#ifndef _DDMEMORY_HPP
#	define _DDMEMORY_HPP 1



#	include "bits/DD_address_of.hpp"
#	include "bits/DD_DefaultDeleter.hpp"
#	if __cplusplus >= 201103L
#		include "bits/DD_make_unique.hpp"
#	else
#		include "bits/DD_UniquePointer.hpp"
#	endif



#endif