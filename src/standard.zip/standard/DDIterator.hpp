// standard/DDIterator.hpp
#ifndef _DDITERATOR_HPP
#	define _DDITERATOR_HPP 1



#	include "bits/DD_IteratorTrait.hpp"



#endif
