// standard/DDArray.hpp
#ifndef _DDARRAY_HPP
#	define _DDARRAY_HPP 1



#	include "bits/DD_Array.hpp"



#endif
