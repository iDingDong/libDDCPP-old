// standard/bits/DD_IsFreeAccessIterator.hpp
#ifndef _DD_IS_FREE_ACCESS_ITERATOR_HPP
#	define _DD_IS_FREE_ACCESS_ITERATOR_HPP 1



#	include "DD_IsBaseOf.hpp"
#	include "DD_IteratorCatagory.hpp"



DD_BEGIN
#	if __cplusplus >= 201103L
template <typename... IteratorsT>
using IsFreeAccessIterator = IsBaseOf<FreeAccessIterator, IteratorCatagoryType<IteratorsT>...>;
#	else
template <typename IteratorT>
struct IsFreeAccessIterator : IsBaseOf<FreeAccessIterator, typename IteratorCatagory<IteratorT>::Type> {
};
#	endif



DD_END



#endif