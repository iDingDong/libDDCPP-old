// This is an experimental header
// standard/bits/_DD_Tuple.hpp
#ifndef __DD_TUPLE_HPP
#	define __DD_TUPLE_HPP 1



#	include "DD_global_definitions"



DD_BEGIN
template <SizeType index_c, typename ValueT>
struct _tuple {
};



template <typename... ValuesT>
struct tuple {
};



DD_END



#endif