// standard/bits/DD_IsVolatile.hpp
#ifndef _DD_IS_Volatile_HPP
#	define _DD_IS_Volatile_HPP 1



#	if __cplusplus >= 201103L
#		include <type_traits>

#		include "DD_And.hpp"
#	else
#		include "DD_IntegralConstant.hpp"
#	endif



DD_DETAIL_BEGIN
template <typename ObjectT>
#	if __cplusplus >= 201103L
struct _IsVolatile : StdBoolConstant<std::is_volatile<ObjectT>> {
#	else
struct _IsVolatile : FalseType {
#	endif
};



template <typename ObjectT>
struct _IsVolatile<ObjectT volatile> : TrueType {
};



DD_DETAIL_END



DD_BEGIN
#	if __cplusplus >= 201103L
template <typename... ObjectsT>
using IsVolatile = AndType<detail::_IsVolatile<ObjectsT>...>;
#	else
template <typename ObjectT>
struct IsVolatile : detail::_IsVolatile<ObjectT> {
};
#	endif



DD_END



#endif
