// standard/bits/DD_swap.hpp
#ifndef _DD_SWAP_HPP
#	define _DD_SWAP_HPP 1



#	if __cplusplus >= 201103L
#		include "DD_IsNoexceptMoveConstructible.hpp"
#		include "DD_IsNoexceptMoveAssignable.hpp"
#		include "DD_move.hpp"
#	else
#		include "DD_global_definitions.hpp"
#	endif



DD_BEGIN
template <typename ObjectT>
inline ProcessType swap(ObjectT& object_1, ObjectT& object_2) DD_NOEXCEPT_IF(
	noexcept(ObjectT(move(object_1))) && noexcept(object_1 = move(object_2))
) {
#	if __cplusplus >= 201103L
	auto temp(move(object_1));
	object_1 = move(object_2);
	object_2 = move(temp);
#	else
	ObjectT temp(object_1);
	object_1 = object_2;
	object_2 = temp;
#	endif
}



template <typename ObjectT, LengthType length_c>
#	if __cplusplus >= 201103L
inline ProcessType swap(ArrayType<ObjectT, length_c>& array_1, ArrayType<ObjectT, length_c>& array_2) noexcept(
	noexcept(swap(*array_1, *array_2))
) {
	for (auto i = 0_DD_Counter; i < length_c; ++i) {
#	else
inline ProcessType swap(ObjectT(&array_1)[length_c], ObjectT(&array_2)[length_c]) {
	for (CounterType i = 0; i < length_c; ++i) {
#	endif
		swap(array_1[i], array_2[i]);
	}
}



DD_END



#endif
