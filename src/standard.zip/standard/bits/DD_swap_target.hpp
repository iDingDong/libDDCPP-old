// standard/bits/DD_swap_target.hpp
#ifndef _DD_SWAP_TARGET_HPP
#	define _DD_SWAP_TARGET_HPP 1



#	include "DD_swap.hpp"



DD_BEGIN
template <typename IteratorT>
inline ProcessType swap_target(
	IteratorT const& iterator_1,
	IteratorT const& iterator_2
) DD_NOEXCEPT_AS(swap(*iterator_1, *iterator_2)) {
	using DD::swap;
	swap(*iterator_1, *iterator_2);
}



DD_END



#endif
