// standard/bits/DD_RemoveReference.hpp
#ifndef _DD_REMOVE_REFERENCE_HPP
#	define _DD_REMOVE_REFERENCE_HPP 1



#	if __cplusplus >= 201103L
#		include <type_traits>
#	endif

#	include "DD_global_definitions.hpp"



DD_BEGIN
template <typename ObjectT>
struct RemoveReference {
#	if __cplusplus >= 201402L
	using Type = std::remove_reference_t<ObjectT>;
#	elif __cplusplus >= 201103L
	using Type = typename std::remove_reference<ObjectT>::type;
#	else
	typedef ObjectT Type;
#	endif
	
	
};



template <typename ObjectT>
struct RemoveReference<ObjectT&> {
	DD_ALIAS(Type, ObjectT)
	
	
};



#	if __cplusplus >= 201103L
template <typename ObjectT>
struct RemoveReference<ObjectT&&> {
	DD_ALIAS(Type, ObjectT)
	
	
};



#	endif
#	if __cplusplus >= 201103L
template <typename ObjectT>
using RemoveReferenceType = typename RemoveReference<ObjectT>::Type;



#	endif
DD_END



#endif