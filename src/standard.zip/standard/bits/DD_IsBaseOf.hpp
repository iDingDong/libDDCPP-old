// standard/bits/DD_IsBaseOf.hpp
#ifndef _DD_IS_BASE_OF_HPP
#	define _DD_IS_BASE_OF_HPP 1



#	if __cplusplus >= 201103L
#		include "DD_Or.hpp"
#	endif
#	include "DD_IsClass.hpp"



DD_DETAIL_BEGIN
template <typename BaseT, typename DerivedT>
struct _IsBaseOfMatcher {
	template <typename BaseT_, typename DerivedT_>
	struct Host {
		DD_CONSTEXPR operator BaseT_*() const DD_NOEXCEPT;
		DD_CONSTEXPR operator DerivedT_*() DD_NOEXCEPT;
		
		
	};
	
	
#	if	__cplusplus >= 201103L
	static FalseType DD_CONSTEXPR match(BaseT*, int) DD_NOEXCEPT;
	
	template <typename IntT_>
	static TrueType DD_CONSTEXPR match(DerivedT*, IntT_) DD_NOEXCEPT {
		return true;
	}
	
	
	static ValidityType DD_CONSTANT value = OrType<
		AndType<decltype(_IsBaseOfMatcher<BaseT, DerivedT>::match(Host<BaseT, DerivedT>(), int())), IsClass<BaseT, DerivedT>>,
		StdIntegralConstant<std::is_base_of<BaseT, DerivedT>>
	>::value;
#	else
	static SizeTrait<2> DD_CONSTEXPR match(BaseT*, int) DD_NOEXCEPT;
	
	template <typename IntT_>
	static SizeTrait<1> DD_CONSTEXPR match(DerivedT*, IntT_) DD_NOEXCEPT;
	
	
	static ValidityType DD_CONSTANT value = BoolConstant<
		sizeof(_IsBaseOfMatcher<BaseT, DerivedT>::match(Host<BaseT, DerivedT>(), int())) == sizeof(SizeTrait<1>) &&
		IsClass<BaseT>::value &&
		IsClass<DerivedT>::value
	>::value;
#	endif
	
	
};



template <typename ObjectT>
struct _IsBaseOfMatcher<ObjectT, ObjectT> {
#	if __cplusplus >= 201103L
	static ValidityType DD_CONSTANT value = IsClass<ObjectT>::value || std::is_base_of<ObjectT, ObjectT>::value;
#	else
	static ValidityType DD_CONSTANT value = IsClass<ObjectT>::value;
#	endif
	
	
};



DD_DETAIL_END



DD_BEGIN
#	if __cplusplus >= 201103L
template <typename BaseT, typename... DerivedsT>
using IsBaseOf = AndType<BoolConstant<detail::_IsBaseOfMatcher<BaseT, DerivedsT>::value>...>;
#	else
template <typename BaseT, typename DerivedT>
struct IsBaseOf : BoolConstant<detail::_IsBaseOfMatcher<BaseT, DerivedT>::value> {
};
#	endif



DD_END



#endif