// standard/bits/DD_compatibility_definitions.hpp
#ifndef _DD_COMPATIBILITY_DEFINITIONS_HPP
#	define _DD_COMPATIBILITY_DEFINITIONS_HPP 1



#	if __cplusplus >= 201103L
#		define DD_STATIC_ASSERT(...) static_assert(__VA_ARGS__)
#	else
#		define DD_STATIC_ASSERT(_ARG_Condition, _ARG_Prompt)
#	endif

#	if __cplusplus >= 201103L
#		define DD_NOEXCEPT noexcept
#		define DD_NOEXCEPT_IF(...) noexcept(__VA_ARGS__)
#		define DD_NOEXCEPT_AS(...) noexcept(noexcept(__VA_ARGS__))
#	else
#		define DD_NOEXCEPT throw()
#		define DD_NOEXCEPT_IF(...)
#		define DD_NOEXCEPT_AS(...)
#	endif

#	if __cplusplus >= 201103L
#		define DD_CONSTEXPR constexpr
#		define DD_CONSTANT constexpr
#	else
#		define DD_CONSTEXPR
#		define DD_CONSTANT const
#	endif

#	if __cplusplus >= 201103L
#		define DD_ALIAS(_ARG_Alias, ...) using _ARG_Alias = __VA_ARGS__;
#	else
#		define DD_ALIAS(_ARG_Alias, _ARG_Origin) typedef _ARG_Origin _ARG_Alias;
#	endif



#	endif