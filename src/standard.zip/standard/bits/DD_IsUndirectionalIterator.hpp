// standard/bits/DD_IsUndirectionalIterator.hpp
#ifndef _DD_IS_UNDIRECTIONAL_ITERATOR_HPP
#	define _DD_IS_UNDIRECTIONAL_ITERATOR_HPP 1



#	include "DD_IsBaseOf.hpp"
#	include "DD_IteratorCatagory.hpp"



DD_BEGIN
#	if __cplusplus >= 201103L
template <typename... IteratorsT>
using IsUndirectionalIterator = IsBaseOf<UndirectionalIterator, IteratorCatagoryType<IteratorsT>...>;
#	else
template <typename IteratorT>
struct IsUndirectionalIterator : IsBaseOf<UndirectionalIterator, typename IteratorCatagory<IteratorT>::Type> {
};
#	endif



DD_END



#endif