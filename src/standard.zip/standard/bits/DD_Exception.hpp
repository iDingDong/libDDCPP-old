// standard/bits/DD_Exception.hpp
#ifndef _DD_EXCEPTION_HPP
#	define _DD_EXCEPTION_HPP 1



#	include "DD_global_definitions.hpp"



DD_BEGIN
struct Exception {
	private:
#	if __cplusplus >= 201103L
	PromptType m_prompt = "Unknown Error. ";
#	else
	PromptType m_prompt;
#	endif
	
	
	public:
#	if __cplusplus >= 201103L
	Exception() DD_NOEXCEPT = default;
	
	public:
	Exception(Exception const& origin) DD_NOEXCEPT = default;
#	else
	Exception() DD_NOEXCEPT : m_prompt() {
	};
#	endif
	
	public:
	DD_CONSTEXPR Exception(PromptType prompt) DD_NOEXCEPT : m_prompt(prompt) {
	}


#	if __cplusplus >= 201103L
	public:
	virtual ~Exception() DD_NOEXCEPT = default;
#	else
	virtual ~Exception() DD_NOEXCEPT {
	}
#	endif
	
	
	public:
	virtual PromptType get_prompt() const DD_NOEXCEPT {
		return m_prompt;
	}
	
	
#	if __cplusplus >= 201103L
	public:
	Exception& operator =(Exception const& origin) DD_NOEXCEPT = default;
	
	
#	endif
};



DD_END



#endif 
