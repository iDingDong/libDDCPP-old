// standard/bits/DD_Functor.hpp
#ifndef _DD_FUNCTOR_HPP
#	define _DD_FUNCTOR_HPP 1



#	include "DD_global_definitions.hpp"



DD_BEGIN
#	if __cplusplus >= 201103L
template <typename ResultT, typename... ArgumentsT>
struct Functor {
	DD_ALIAS(ResultType, ResultT)
	
	
};



#	endif
template <typename ResultT, typename ArgumentT>
struct UnaryFunctor {
	DD_ALIAS(ResultType, ResultT)
	DD_ALIAS(ArgumentType, ArgumentT)
	
	
};



template <typename ResultT, typename ArgumentT1, typename ArgumentT2>
struct BinaryFunctor {
	DD_ALIAS(ResultType, ResultT)
	DD_ALIAS(FirstArgumentType, ArgumentT1)
	DD_ALIAS(SecondArgumentType, ArgumentT2)
	
	
};



DD_END



#endif