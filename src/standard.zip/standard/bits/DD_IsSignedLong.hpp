// standard/bits/DD_IsSignedLong.hpp
#ifndef _DD_IS_SIGNED_LONG_HPP
#	define _DD_IS_SIGNED_LONG_HPP 1



#	if __cplusplus >= 201103L
#		include "DD_And.hpp"
#	else
#		include "DD_IntegralConstant.hpp"
#	endif
#	include "DD_RemoveCV.hpp"



DD_DETAIL_BEGIN
template <typename ObjectT>
struct _IsSignedLong : FalseType {
};



template <>
struct _IsSignedLong<signed long> : TrueType {
};



DD_DETAIL_END



DD_BEGIN
#	if __cplusplus >= 201103L
template <typename... ObjectsT>
using IsSignedLong = AndType<detail::_IsSignedLong<RemoveCVType<ObjectsT>>...>;
#	else
template <typename ObjectT>
struct IsSignedLong : detail::_IsSignedLong<typename RemoveCV<ObjectT>::Type> {
};
#	endif



DD_END



#endif
