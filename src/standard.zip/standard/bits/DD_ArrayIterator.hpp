// standard/bits/DD_ArrayIterator.hpp
#ifndef _DD_ARRAY_ITERATOR_HPP
#	define _DD_ARRAY_ITERATOR_HPP 1



#	include "DD_IteratorTrait.hpp"



DD_BEGIN
template <typename ValueT>
struct ArrayIterator {
	public:
	DD_ALIAS(ThisType, ArrayIterator<ValueT>)
	DD_ALIAS(ValueType, ValueT)
	
	public:
	DD_ALIAS(ReferenceType, ValueType&)
	DD_ALIAS(PointerType, ValueType*)
	DD_ALIAS(DifferenceType, DD::DifferenceType)
	DD_ALIAS(CatagoryType, FreeAccessIterator)
	
	public:
	DD_COMPAT_STL_ITERATOR
	
	
	private:
#	if __cplusplus >= 201103L
	PointerType m_pointer = PointerType();
#	else
	PointerType m_pointer;
#	endif
	
	
#	if __cplusplus >= 201103L
	public:
	DD_CONSTEXPR ArrayIterator() DD_NOEXCEPT = default;
	
	public:
	DD_CONSTEXPR ArrayIterator(ThisType const& origin) DD_NOEXCEPT = default;
#	else
	DD_CONSTEXPR ArrayIterator() DD_NOEXCEPT : m_pointer() {
	}
#	endif
	
	public:
	DD_CONSTEXPR ArrayIterator(PointerType new_pointer) DD_NOEXCEPT : m_pointer(new_pointer) {
	};
	
	
#	if __cplusplus >= 201103L
	public:
	~ArrayIterator() noexcept(true) = default;
	
	
#	endif
	public:
	ValidityType DD_CONSTEXPR equal(ThisType const& target) const DD_NOEXCEPT {
		return this->m_pointer == target.m_pointer;
	}
	
	
	public:
	ValidityType DD_CONSTEXPR less(ThisType const& target) const DD_NOEXCEPT {
		return this->m_pointer < target.m_pointer;
	}
	
	
	public:
	ValidityType DD_CONSTEXPR distance(ThisType const& target) const DD_NOEXCEPT {
		return target.m_pointer - this->m_pointer;
	}
	
	
	public:
	PointerType DD_CONSTEXPR get_pointer() const DD_NOEXCEPT {
		return this->m_pointer;
	}
	
	
#	if __cplusplus >= 201103L
	public:
	ThisType& operator =(ThisType const&) noexcept(true) = default;
	
	
#	endif
	public:
	ThisType& operator ++() DD_NOEXCEPT {
		++this->m_pointer;
		return *this;
	}
	
	public:
	ThisType operator ++(int) DD_NOEXCEPT {
		return ThisType(this->m_pointer++);
	}
	
	
	public:
	ThisType& operator --() DD_NOEXCEPT {
		--this->m_pointer;
		return *this;
	}
	
	public:
	ThisType operator --(int) DD_NOEXCEPT {
		return ThisType(this->m_pointer++);
	}
	
	
	public:
	ThisType& operator +=(DifferenceType step) DD_NOEXCEPT {
		this->m_pointer += step;
		return *this;
	}
	
	
	public:
	ThisType& operator -=(DifferenceType step) DD_NOEXCEPT {
		this->m_pointer -= step;
		return *this;
	}
	
	
	public:
	ReferenceType operator [](DifferenceType index) const DD_NOEXCEPT {
		return this->m_pointer[index];
	}
	
	
	public:
	ReferenceType operator *() const DD_NOEXCEPT {
		return *this->m_pointer;
	}
	
	
	public:
	PointerType operator ->() const DD_NOEXCEPT {
		return *this->m_pointer;
	}
	
	
	public:
#	if __cplusplus >= 201103L
	explicit operator ValidityType() const DD_NOEXCEPT {
		return this->m_pointer;
	}
	
	
#	endif
};



template <typename ValueT>
inline ArrayIterator<ValueT> DD_CONSTEXPR operator +(ArrayIterator<ValueT> array_iterator, typename ArrayIterator<ValueT>::DifferenceType step) DD_NOEXCEPT {
	return array_iterator += step;
}

template <typename ValueT>
inline ArrayIterator<ValueT> DD_CONSTEXPR operator +(typename ArrayIterator<ValueT>::DifferenceType step, ArrayIterator<ValueT> array_iterator) DD_NOEXCEPT {
	return array_iterator += step;
}


template <typename ValueT>
inline typename ArrayIterator<ValueT>::DifferenceType DD_CONSTEXPR operator -(
	ArrayIterator<ValueT> const& array_iterator_1,
	ArrayIterator<ValueT> const& array_iterator_2
) DD_NOEXCEPT {
	return array_iterator_2.distance(array_iterator_1);
}

template <typename ValueT>
inline ArrayIterator<ValueT> DD_CONSTEXPR operator -(ArrayIterator<ValueT> array_iterator, typename ArrayIterator<ValueT>::DifferenceType step) DD_NOEXCEPT {
	return array_iterator -= step;
}


template <typename ValueT>
inline ValidityType DD_CONSTEXPR operator ==(ArrayIterator<ValueT> const& array_iterator_1, ArrayIterator<ValueT> const& array_iterator_2) DD_NOEXCEPT {
	return array_iterator_1.equal(array_iterator_2);
}


template <typename ValueT>
inline ValidityType DD_CONSTEXPR operator <(ArrayIterator<ValueT> const& array_iterator_1, ArrayIterator<ValueT> const& array_iterator_2) DD_NOEXCEPT {
	return array_iterator_1.less(array_iterator_2.m_pointer);
}



DD_END



#endif