// standard/bits/DD_RemoveVolatile.hpp
#ifndef _DD_REMOVE_VOLATILE_HPP
#	define _DD_REMOVE_VOLATILE_HPP 1



#	if __cplusplus >= 201103L
#		include <type_traits>
#	endif

#	include "DD_global_definitions.hpp"



DD_BEGIN
template <typename ObjectT>
struct RemoveVolatile {
#	if __cplusplus >= 201402L
	using Type = std::remove_volatile_t<ObjectT>;
#	elif __cplusplus >= 201103L
	using Type = typename std::remove_volatile<ObjectT>::type;
#	else
	typedef ObjectT Type;
#	endif
	
	
};



template <typename ObjectT>
struct RemoveVolatile<ObjectT volatile> {
	DD_ALIAS(Type, ObjectT)
	
	
};



#	if __cplusplus >= 201103L
template <typename ObjectT>
using RemoveVolatileType = typename RemoveVolatile<ObjectT>::Type;



#	endif
DD_END



#endif