// standard/bits/DD_RemoveExtent.hpp
#ifndef _DD_REMOVE_EXTENT_HPP
#	define _DD_REMOVE_EXTENT_HPP 1



#	if __cplusplus >= 201103L
#		include <type_traits>

#	endif
#	include "DD_global_definitions.hpp"



DD_BEGIN
template <typename ObjectT>
struct RemoveExtent {
#	if __cplusplus >= 201402L
	using Type = std::remove_extent_t<ObjectT>;
#	elif __cplusplus >= 201103L
	using Type = typename std::remove_extent<ObjectT>::type;
#	else
	typedef ObjectT Type;
#	endif
	
	
};



template <typename ObjectT, LengthType length_c>
struct RemoveExtent<ObjectT[length_c]> {
	DD_ALIAS(Type, ObjectT)
	
	
};



template <typename ObjectT>
struct RemoveExtent<ObjectT[]> {
	DD_ALIAS(Type, ObjectT)
	
	
};



#	if __cplusplus >= 201103L
template <typename ObjectT>
using RemoveExtentType = typename RemoveExtent<ObjectT>::Type;



#	endif
DD_END



#endif