// standard/bits/DD_AddCV.hpp
#ifndef _DD_ADD_C_V_HPP
#	define _DD_ADD_C_V_HPP 1



#	include "DD_AddConst.hpp"
#	include "DD_AddVolatile.hpp"



DD_BEGIN
#	if __cplusplus >= 201103L
template <typename ObjectT>
using AddCV = AddConst<AddVolatileType<ObjectT>>;
template <typename ObjectT>
using AddCVType = typename AddCV<ObjectT>::Type;
#	else
template <typename ObjectT>
struct AddCV : AddConst<typename AddVolatile<ObjectT>::Type> {
};
#	endif



DD_END



#endif