// standard/bits/DD_IsArray.hpp
#ifndef _DD_IS_ARRAY_HPP
#	define _DD_IS_ARRAY_HPP 1



#	if __cplusplus >= 201103L
#		include <type_traits>

#		include "DD_And.hpp"
#	else
#		include "DD_IntegralConstant.hpp"
#	endif
#	include "DD_Nil.hpp"



DD_DETAIL_BEGIN
template <typename ObjectT>
#	if __cplusplus >= 201103L
struct _IsArray : StdBoolConstant<std::is_array<ObjectT>> {
#	else
struct _IsArray : FalseType {
#	endif
};



template <typename ValueT>
struct _IsArray<ValueT[]> : TrueType {
};



template <typename ValueT, LengthType length_c>
struct _IsArray<ValueT[length_c]> : TrueType {
};



DD_DETAIL_END



DD_BEGIN
#	if __cplusplus >= 201103L
template <typename... ObjectsT>
using IsArray = AndType<detail::_IsArray<ObjectsT>...>;
#	else
template <typename ObjectT>
struct IsArray : detail::_IsArray<ObjectT> {
};
#	endif



DD_END



#endif
