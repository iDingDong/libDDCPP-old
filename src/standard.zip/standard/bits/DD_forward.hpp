// standard/bits/DD_forward.hpp
#ifndef _DD_FORWARD_HPP
#	define _DD_FORWARD_HPP 1



#	if __cplusplus < 201103L
#		error ISO/IEC 14882:2011 or a later version support is required for'DD::forward'.



#	endif
#	include "DD_IsLvalueReference.hpp"
#	include "DD_RemoveReference.hpp"



DD_BEGIN
template <typename ObjectT>
inline ObjectT&& forward(RemoveReferenceType<ObjectT>& object) noexcept(true) {
	return static_cast<ObjectT&&>(object);
}

template <typename ObjectT>
inline ObjectT&& forward(RemoveReferenceType<ObjectT>&& object) noexcept(true) {
	static_assert(!IsLvalueReference<ObjectT>::value, "Template argument substituting 'ObjectT' is an lvalue reference type");
	return static_cast<ObjectT&&>(object);
}



DD_END



#endif