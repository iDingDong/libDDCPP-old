// standard/bits/DD_Array.hpp
#ifndef _DD_ARRAY_HPP
#	define _DD_ARRAY_HPP 1



#	include "DD_CompatStlContainer.hpp"
#	include "DD_AccessDenied.hpp"
#	include "DD_ArrayIterator.hpp"



DD_BEGIN
template <typename ValueT, LengthType length_c>
struct Array {
#	if __cplusplus >= 201103L
	using ThisType = Array<ValueT, length_c>;
#	else
	typedef Array<ValueT, length_c> ThisType;
#	endif
	DD_ALIAS(ValueType, ValueT)
	static LengthType DD_CONSTANT length_constant = length_c;
	
	DD_ALIAS(ReferenceType, ValueType&)
	DD_ALIAS(ConstReferenceType, ValueType const&)
	DD_ALIAS(PointerType, ValueType*)
	DD_ALIAS(ConstPointerType, ValueType const*)
	
	DD_ALIAS(Iterator, ArrayIterator<ValueType>)
	DD_ALIAS(ReverseIterator, typename IteratorReverse<Iterator>::Type)
	DD_ALIAS(ConstIterator, ArrayIterator<ValueType const>)
	DD_ALIAS(ConstReverseIterator, typename IteratorReverse<ConstIterator>::Type)
	
	DD_COMPAT_STL_CONTAINER
	
#	if __cplusplus >= 201103L
	using ArrayType = DD::ArrayType<ValueType, length_constant>;
#	else
	typedef ValueType ArrayType[length_constant];
#	endif
	
	
	ArrayType m_array;
	
	
	static LengthType DD_CONSTEXPR get_length() DD_NOEXCEPT {
		return ThisType::length_constant;
	}
	
	
	static ValidityType DD_CONSTEXPR is_empty() DD_NOEXCEPT {
		return false;
	}
	
	
	ReferenceType at(LengthType index) {
		if (index >= length_constant) {
			throw AccessDenied("'DD::Array::at' in " __FILE__ " at " DD_TO_STRING(__LINE__));
		}
		return this->m_array[index];
	}
	
	ConstReferenceType DD_CONSTEXPR at(LengthType index) const {
#	if __cplusplus >= 201402L || __cplusplus < 201103L
		if (index >= length_constant) {
			throw AccessDenied("'DD::Array::at' in " __FILE__ " at " DD_TO_STRING(__LINE__));
		}
		return this->m_array[index];
#	else
		return index < length_constant ? this->m_array[index] : (
			throw AccessDenied("'DD::Array::at' in " __FILE__ " at " DD_TO_STRING(__LINE__)),  *this->m_array
		);
#	endif
	}
	
	
	Iterator begin() DD_NOEXCEPT {
		return Iterator(this->m_array);
	}
	
	
	Iterator end() DD_NOEXCEPT {
		return Iterator(this->m_array + length_constant);
	}
	
	
	ReverseIterator rbegin() DD_NOEXCEPT {
		return ReverseIterator(this->m_array + length_constant - 1);
	}
	
	
	ReverseIterator rend() DD_NOEXCEPT {
		return ReverseIterator(this->m_array - 1);
	}
	
	
	ConstIterator cbegin() DD_NOEXCEPT {
		return ConstIterator(this->m_array);
	}
	
	
	ConstIterator cend() DD_NOEXCEPT {
		return ConstIterator(this->m_array + length_constant);
	}
	
	
	ConstReverseIterator crbegin() DD_NOEXCEPT {
		return ConstReverseIterator(this->m_array - 1);
	}
	
	
	ConstReverseIterator crend() DD_NOEXCEPT {
		return ConstReverseIterator(this->m_array + length_constant - 1);
	}
	
	
	ReferenceType operator [](LengthType index) DD_NOEXCEPT {
		return this->m_array[index];
	}
	
	ConstReferenceType DD_CONSTEXPR operator [](LengthType index) const DD_NOEXCEPT {
		return this->m_array[index];
	}
	
	
	ReferenceType operator *() DD_NOEXCEPT {
		return *this->m_array;
	}
	
	ConstReferenceType DD_CONSTEXPR operator *() const DD_NOEXCEPT {
		return *this->m_array;
	}
	
	
};



template <typename ValueT>
struct Array<ValueT, 0> {
	DD_ALIAS(ValueType, ValueT)
	static LengthType DD_CONSTANT length_constant = 0;
#	if __cplusplus >= 201103L
	using ThisType = Array<ValueType, length_constant>;
#	else
	typedef Array<ValueType, length_constant> ThisType;
#	endif
	
	DD_ALIAS(ReferenceType, ValueType&)
	DD_ALIAS(ConstReferenceType, ValueType const&)
	DD_ALIAS(PointerType, ValueType*)
	DD_ALIAS(ConstPointerType, ValueType const*)
	
	DD_ALIAS(Iterator, ArrayIterator<ValueType>)
	DD_ALIAS(ReverseIterator, typename IteratorReverse<Iterator>::Type)
	DD_ALIAS(ConstIterator, ArrayIterator<ValueType const>)
	DD_ALIAS(ConstReverseIterator, typename IteratorReverse<ConstIterator>::Type)
	
	DD_COMPAT_STL_CONTAINER
	
	
	static LengthType DD_CONSTEXPR get_length() DD_NOEXCEPT {
		return ThisType::length_constant;
	}
	
	
	static ValidityType DD_CONSTEXPR is_empty() DD_NOEXCEPT {
		return true;
	}
	
	
	Iterator begin() DD_NOEXCEPT {
		return Iterator();
	}
	
	
	Iterator end() DD_NOEXCEPT {
		return Iterator();
	}
	
	
	ReverseIterator rbegin() DD_NOEXCEPT {
		return ReverseIterator();
	}
	
	
	ReverseIterator rend() DD_NOEXCEPT {
		return ReverseIterator();
	}
	
	
	ConstIterator cbegin() DD_NOEXCEPT {
		return ConstIterator();
	}
	
	
	ConstIterator cend() DD_NOEXCEPT {
		return ConstIterator();
	}
	
	
	ConstReverseIterator crbegin() DD_NOEXCEPT {
		return ConstReverseIterator();
	}
	
	
	ConstReverseIterator crend() DD_NOEXCEPT {
		return ConstReverseIterator();
	}
	
	
};



DD_END



#endif