// standard/bits/DD_Pair.hpp
#ifndef _DD_PAIR_HPP
#	define _DD_PAIR_HPP



#	include "DD_relationship_operators.hpp"
#	include "DD_swap.hpp"



DD_DETAIL_BEGIN
template <typename ValueT1, typename ValueT2>
struct _PairBase {
	
	
	
};



DD_DETAIL_END



DD_BEGIN
template <typename ValueT1, typename ValueT2>
struct Pair {
	public:
	DD_ALIAS(FirstValueType, ValueT1)
	DD_ALIAS(SecondValueType, ValueT2)
#	if __cplusplus >= 201103L
	using ThisType = Pair<FirstValueType, SecondValueType>;
#	else
	typedef Pair<FirstValueType, SecondValueType> ThisType;
#	endif
	
	
	public:
	FirstValueType first;
	SecondValueType second;
	
	
	public:
	ProcessType swap(ThisType& target) DD_NOEXCEPT_IF(
		noexcept(DD::swap(first, target.first)) && noexcept(DD::swap(second, target.second))
	) {
		using DD::swap;
		swap(this->first, target.first);
		swap(this->second, target.second);
	}
	
	
};



template <typename ValueT>
struct Pair<ValueT, ValueT> {
	public:
	DD_ALIAS(ValueType, ValueT)
#	if __cplusplus >= 201103L
	using ThisType = Pair<ValueType, ValueType>;
#	else
	typedef Pair<ValueType, ValueType> ThisType;
#	endif
	
	DD_ALIAS(FirstValueType, ValueType)
	DD_ALIAS(SecondValueType, ValueType)
	
	
	public:
	FirstValueType first;
	SecondValueType second;
	
	
	public:
	ProcessType swap() DD_NOEXCEPT_AS(DD::swap(first, second)) {
		using DD::swap;
		swap(this->first, this->second);
	}
	
	public:
	ProcessType swap(ThisType& target) DD_NOEXCEPT_AS(DD::swap(first, target.first)) {
		using DD::swap;
		swap(this->first, target.first);
		swap(this->second, target.second);
	}
	
	
};



template <typename ValueT>
inline ProcessType swap(Pair<ValueT, ValueT>& pair) DD_NOEXCEPT_AS(pair.swap()) {
	pair.swap();
}



template <typename ValueT1, typename ValueT2>
inline ValidityType DD_CONSTEXPR operator ==(
	Pair<ValueT1, ValueT2> const& pair_1,
	Pair<ValueT1, ValueT2> const& pair_2
) DD_NOEXCEPT_IF(noexcept(pair_1.first == pair_2.first) && noexcept(pair_1.second == pair_2.second)) {
	return pair_1.first == pair_2.first && pair_1.second == pair_2.second;
}



template <typename ValueT1, typename ValueT2>
inline ValidityType DD_CONSTEXPR operator <(
	Pair<ValueT1, ValueT2> const& pair_1,
	Pair<ValueT1, ValueT2> const& pair_2
) DD_NOEXCEPT_IF(noexcept(pair_1.first < pair_2.first) && noexcept(pair_1.second < pair_2.second)) {
	return pair_1.first < pair_2.first || (pair_1.first == pair_2.first && pair_1.second < pair_2.second);
}



DD_END



#endif
