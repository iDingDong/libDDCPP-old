// standard/bits/DD_IsSignedInt.hpp
#ifndef _DD_IS_SIGNED_INT_HPP
#	define _DD_IS_SIGNED_INT_HPP 1



#	if __cplusplus >= 201103L
#		include "DD_And.hpp"
#	else
#		include "DD_IntegralConstant.hpp"
#	endif
#	include "DD_RemoveCV.hpp"



DD_DETAIL_BEGIN
template <typename ObjectT>
struct _IsSignedInt : FalseType {
};



template <>
struct _IsSignedInt<signed int> : TrueType {
};



DD_DETAIL_END



DD_BEGIN
#	if __cplusplus >= 201103L
template <typename... ObjectsT>
using IsSignedInt = AndType<detail::_IsSignedInt<RemoveCVType<ObjectsT>>...>;
#	else
template <typename ObjectT>
struct IsSignedInt : detail::_IsSignedInt<typename RemoveCV<ObjectT>::Type> {
};
#	endif



DD_END



#endif
