// standard/bits/DD_IsSignedLongLong.hpp
#ifndef _DD_IS_SIGNED_LONG_LONG_HPP
#	define _DD_IS_SIGNED_LONG_LONG_HPP 1



#	if __cplusplus < 201103L
#		error ISO/IEC 14882:2011 or a later version support is required for'DD::IsLongLong'.
#	endif



#	include "DD_And.hpp"
#	include "DD_RemoveCV.hpp"



DD_DETAIL_BEGIN
template <typename ObjectT>
struct _IsSignedLongLong : FalseType {
};



template <>
struct _IsSignedLongLong<signed long long> : TrueType {
};



DD_DETAIL_END



DD_BEGIN
template <typename... ObjectsT>
using IsSignedLongLong = AndType<detail::_IsSignedLongLong<RemoveCVType<ObjectsT>>...>;



DD_END



#endif
