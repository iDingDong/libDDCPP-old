// standard/bits/ DD_IsSame.hpp
#ifndef _DD_IS_SAME_HPP
#	define _DD_IS_SAME_HPP 1



#	if __cplusplus >= 201103L
#		include <type_traits>

#		include "DD_And.hpp"
#	else
#		include "DD_IntegralConstant.hpp"
#	endif



DD_DETAIL_BEGIN
#	if __cplusplus >= 201103L
template <typename... ObjectsT>
struct _IsSame : TrueType {
};



template <typename ObjectT1, typename ObjectT2, typename... ObjectsT>
struct _IsSame<ObjectT1, ObjectT2, ObjectsT...> : AndType<_IsSame<ObjectT1, ObjectT2>, _IsSame<ObjectT1, ObjectsT...>> {
};



template <typename ObjectT1, typename ObjectT2>
struct _IsSame<ObjectT1, ObjectT2> : StdBoolConstant<std::is_same<ObjectT1, ObjectT2>> {
};
#	else
template <typename ObjectT1, typename ObjectT2>
struct _IsSame : FalseType {
};
#	endif



template <typename ObjectT>
struct _IsSame<ObjectT, ObjectT> : TrueType {
};



DD_DETAIL_END



DD_BEGIN
#	if __cplusplus >= 201103L
template <typename... ObjectsT>
using IsSame = detail::_IsSame<ObjectsT...>;
#	else
template <typename ObjectT1, typename ObjectT2>
struct IsSame : detail::_IsSame<ObjectT1, ObjectT2> {
};
#	endif



DD_END



#endif
