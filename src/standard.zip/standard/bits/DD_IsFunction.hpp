// standard/bits/DD_IsFunction.hpp
#ifndef _DD_IS_FUNCTION_HPP
#	define _DD_IS_FUNCTION_HPP 1



#	if __cplusplus < 201103L
#		error ISO/IEC 14882:2011 or a later version support is required for'DD::IsFunction'.
#	endif



#	include <type_traits>
#	include "DD_And.hpp"



DD_DETAIL_BEGIN
template <typename ObjectT>
#	if __cplusplus >= 201103L
struct _IsFunction : StdIntegralConstant<std::is_function<ObjectT>> {
#	else
struct _IsFunction : FalseType {
#	endif
};



template <typename ResultT, typename... ArgumentsT>
struct _IsFunction<ResultT(ArgumentsT...)> : TrueType {
};



template <typename ResultT, typename... ArgumentsT>
struct _IsFunction<ResultT(ArgumentsT... ...)> : TrueType {
};



template <typename ResultT, typename... ArgumentsT>
struct _IsFunction<ResultT(ArgumentsT...) const> : TrueType {
};



template <typename ResultT, typename... ArgumentsT>
struct _IsFunction<ResultT(ArgumentsT...) volatile> : TrueType {
};



template <typename ResultT, typename... ArgumentsT>
struct _IsFunction<ResultT(ArgumentsT...) const volatile> : TrueType {
};



template <typename ResultT, typename... ArgumentsT>
struct _IsFunction<ResultT(ArgumentsT... ...) const> : TrueType {
};



template <typename ResultT, typename... ArgumentsT>
struct _IsFunction<ResultT(ArgumentsT... ...) volatile> : TrueType {
};



template <typename ResultT, typename... ArgumentsT>
struct _IsFunction<ResultT(ArgumentsT... ...) const volatile> : TrueType {
};



template <typename ResultT, typename... ArgumentsT>
struct _IsFunction<ResultT(ArgumentsT...)&> : TrueType {
};



template <typename ResultT, typename... ArgumentsT>
struct _IsFunction<ResultT(ArgumentsT...) const&> : TrueType {
};



template <typename ResultT, typename... ArgumentsT>
struct _IsFunction<ResultT(ArgumentsT...) volatile&> : TrueType {
};



template <typename ResultT, typename... ArgumentsT>
struct _IsFunction<ResultT(ArgumentsT...) const volatile&> : TrueType {
};



template <typename ResultT, typename... ArgumentsT>
struct _IsFunction<ResultT(ArgumentsT... ...)&> : TrueType {
};



template <typename ResultT, typename... ArgumentsT>
struct _IsFunction<ResultT(ArgumentsT... ...) const&> : TrueType {
};



template <typename ResultT, typename... ArgumentsT>
struct _IsFunction<ResultT(ArgumentsT... ...) volatile&> : TrueType {
};



template <typename ResultT, typename... ArgumentsT>
struct _IsFunction<ResultT(ArgumentsT... ...) const volatile&> : TrueType {
};



template <typename ResultT, typename... ArgumentsT>
struct _IsFunction<ResultT(ArgumentsT...)&&> : TrueType {
};



template <typename ResultT, typename... ArgumentsT>
struct _IsFunction<ResultT(ArgumentsT...) const&&> : TrueType {
};



template <typename ResultT, typename... ArgumentsT>
struct _IsFunction<ResultT(ArgumentsT...) volatile&&> : TrueType {
};



template <typename ResultT, typename... ArgumentsT>
struct _IsFunction<ResultT(ArgumentsT...) const volatile&&> : TrueType {
};



template <typename ResultT, typename... ArgumentsT>
struct _IsFunction<ResultT(ArgumentsT... ...)&&> : TrueType {
};



template <typename ResultT, typename... ArgumentsT>
struct _IsFunction<ResultT(ArgumentsT... ...) const&&> : TrueType {
};



template <typename ResultT, typename... ArgumentsT>
struct _IsFunction<ResultT(ArgumentsT... ...) volatile&&> : TrueType {
};



template <typename ResultT, typename... ArgumentsT>
struct _IsFunction<ResultT(ArgumentsT... ...) const volatile&&> : TrueType {
};



DD_DETAIL_END



DD_BEGIN
template <typename... ObjectsT>
using IsFunction = AndType<detail::_IsFunction<ObjectsT>...>;



DD_END



#endif