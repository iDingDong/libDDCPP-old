// standard/bits/DD_select_sort.hpp
#ifndef _DD_SELECT_SORT_HPP
#	define _DD_SELECT_SORT_HPP



#	include "DD_swap_target.hpp"



DD_BEGIN
template <typename UndirectionalIteratorT>
ProcessType select_sort(UndirectionalIteratorT begin, UndirectionalIteratorT const& end) DD_NOEXCEPT_IF(
	noexcept(begin != end) &&
	noexcept(++begin) &&
	noexcept(UndirectionalIteratorT()) &&
	noexcept(begin = begin) &&
	noexcept(*begin < *begin) &&
	noexcept(swap_target(begin, begin))
) {
	for (UndirectionalIteratorT current, tagged; begin != end; ++begin) {
		current = begin;
		tagged = current;
		while (++current != end) {
			if (*current < *tagged) {
				tagged = current;
			}
		}
		using DD::swap_target;
		swap_target(begin, tagged);
	}
}



DD_END



#endif