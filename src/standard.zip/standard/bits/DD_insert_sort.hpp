// standard/bits/DD_insert_sort.hpp
#ifndef _DD_INSERT_SORT_HPP
#	define _DD_INSERT_SORT_HPP


#	if __cplusplus >= 201103L
#		include "DD_move.hpp"
#	else
#		include "DD_IteratorValue.hpp"
#	endif
#	include "DD_IsBidirectionalIterator.hpp"
#	include "DD_swap_target.hpp"



DD_DETAIL_BEGIN
template <typename UndirectionalIteratorT, ValidityType IsBidirectionalIteratorT>
struct _InsertSortImplement {
	static ProcessType insert_sort(UndirectionalIteratorT const& begin, UndirectionalIteratorT const& end) DD_NOEXCEPT_IF(false) {
		if (begin != end) {
			for (UndirectionalIteratorT current(begin), front; ++current != end; ) {
				front = begin;
				do {
					if (*current < *front) {
						do {
							using DD::swap_target;
							swap_target(front, current);
						} while (++front != current);
						break;
					}
				} while (++front != current);
			}
		}
	}
	
	
};



template <typename BidirectionalIteratorT>
struct _InsertSortImplement<BidirectionalIteratorT, true> {
	static ProcessType insert_sort(BidirectionalIteratorT const& begin, BidirectionalIteratorT const& end) DD_NOEXCEPT_IF(false) {
		if (begin != end) {
			for (BidirectionalIteratorT current(begin), front; ++current != end; ) {
				front = current;
#	if __cplusplus >= 201103L
				auto temp = move(*front);
				for (auto previous(front); temp < *--previous; ) {
					*front = move(*previous);
					front = previous;
					if (front == begin) {
						break;
					}
				}
				*front = move(temp);
#	else
				typename IteratorValue<BidirectionalIteratorT>::Type temp = *current;
				for (BidirectionalIteratorT previous(front); temp < *--previous; ) {
					*front = *previous;
					front = previous;
					if (previous == begin) {
						break;
					}
				}
				*front = temp;
#	endif
			}
		}
	}
	
	
};



DD_DETAIL_END



DD_BEGIN
template <typename UndirectionalIteratorT>
ProcessType insert_sort(UndirectionalIteratorT const& begin, UndirectionalIteratorT const& end) DD_NOEXCEPT_AS(
	detail::_InsertSortImplement<UndirectionalIteratorT, IsBidirectionalIterator<UndirectionalIteratorT>::value>::insert_sort(begin, end)
) {
	detail::_InsertSortImplement<UndirectionalIteratorT, IsBidirectionalIterator<UndirectionalIteratorT>::value>::insert_sort(begin, end);
}



DD_END



#endif