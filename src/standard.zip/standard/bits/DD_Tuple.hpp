// standard/bits/DD_Tuple.hpp
#ifndef _DD_TUPLE_HPP
#	define _DD_TUPLE_HPP 1



#	if __cplusplus < 201103L
#		error ISO/IEC 14882:2011 or a later version support is required for'DD::Tuple'.



#	endif
#	include "DD_forward.hpp"
#	include "DD_UniquePointer.hpp"



DD_DETAIL_BEGIN
template <SubscriptType subscript_c, typename... ValuesT>
struct _TupleImplement;



template <SubscriptType subscript_c, typename ValueT, typename... ValuesT>
struct _TupleImplement<subscript_c, ValueT, ValuesT...> : _TupleImplement<subscript_c, ValueT>, _TupleImplement<subscript_c + 1, ValuesT...> {
	public:
	using ThisType = _TupleImplement<subscript_c, ValueT, ValuesT...>;
	static SubscriptType constexpr subscript_constant = subscript_c;
	using ValueType = ValueT;
	
	static LengthType constexpr length_constant = sizeof...(ValuesT) + 1;
	
	
	public:
	constexpr _TupleImplement() = default;
	
	public:
	constexpr _TupleImplement(ThisType const&) = default;
	
	public:
	constexpr _TupleImplement(ThisType&&) = default;
	
	public:
	template <typename ValueT_, typename... ValuesT_>
	constexpr _TupleImplement(ValueT_&& value, ValuesT_&&... values) noexcept(
		noexcept(_TupleImplement<subscript_c, ValueT>(forward<ValueT_>(value))) &&
		noexcept(_TupleImplement<subscript_c + 1, ValuesT...>(forward<ValuesT_>(values)...))
	) : _TupleImplement<subscript_c, ValueT>(forward<ValueT_>(value)), _TupleImplement<subscript_c + 1, ValuesT...>(forward<ValuesT_>(values)...) {
	}
	
	
};



template <SubscriptType subscript_c, typename ValueT>
struct _TupleImplement<subscript_c, ValueT> {
	public:
	using ThisType = _TupleImplement<subscript_c, ValueT>;
	static SubscriptType constexpr subscript_constant = subscript_c;
	using ValueType = ValueT;
	
	
	private:
	UniquePointer<ValueType> m_pointer = UniquePointer<ValueType>(new ValueType());
	
	
	public:
	constexpr _TupleImplement() = default;
	
	public:
	constexpr _TupleImplement(ThisType const& origin) noexcept(noexcept(ValueType(*origin.m_pointer))) : m_pointer(new ValueType(*origin.m_pointer)) {
	}
	
	public:
	constexpr _TupleImplement(ThisType&&) = default;
	
	public:
	template <typename ValueT_>
	constexpr _TupleImplement(ValueT_&& value) : m_pointer(new ValueType(forward<ValueT_>(value))) {
	}
	
	
	public:
	ValueType& get_value() noexcept {
		return *m_pointer;
	}
	
	public:
	ValueType const& get_value() const noexcept {
		return *m_pointer;
	}
	
	
};



template <>
struct _TupleImplement<0> {
	static SubscriptType constexpr subscript_constant = 0;
	
	
};



DD_DETAIL_END



DD_BEGIN
template <typename... ValuesT>
using Tuple = detail::_TupleImplement<0, ValuesT...>;



template <SubscriptType index_c, typename ValueT>
ValueT& get_value(detail::_TupleImplement<index_c, ValueT>& tuple) {
	return tuple.get_value();
}

template <SubscriptType index_c, typename ValueT>
ValueT const& get_value(detail::_TupleImplement<index_c, ValueT> const& tuple) {
	return tuple.get_value();
}

template <typename ValueT, SubscriptType index_c>
ValueT& get_value(detail::_TupleImplement<index_c, ValueT>& tuple) {
	return tuple.get_value();
}

template <typename ValueT, SubscriptType index_c>
ValueT const& get_value(detail::_TupleImplement<index_c, ValueT> const& tuple) {
	return tuple.get_value();
}



DD_END



#endif