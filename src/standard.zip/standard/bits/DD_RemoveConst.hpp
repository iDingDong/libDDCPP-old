// standard/bits/DD_RemoveConst.hpp
#ifndef _DD_REMOVE_CONST_HPP
#	define _DD_REMOVE_CONST_HPP 1



#	if __cplusplus >= 201103L
#		include <type_traits>
#	endif

#	include "DD_global_definitions.hpp"



DD_BEGIN
template <typename ObjectT>
struct RemoveConst {
#	if __cplusplus >= 201402L
	using Type = std::remove_const_t<ObjectT>;
#	elif __cplusplus >= 201103L
	using Type = typename std::remove_const<ObjectT>::type;
#	else
	typedef ObjectT Type;
#	endif
	
	
};



template <typename ObjectT>
struct RemoveConst<ObjectT const> {
	DD_ALIAS(Type, ObjectT)
	
	
};



#	if __cplusplus >= 201103L
template <typename ObjectT>
using RemoveConstType = typename RemoveConst<ObjectT>::Type;



#	endif
DD_END



#endif