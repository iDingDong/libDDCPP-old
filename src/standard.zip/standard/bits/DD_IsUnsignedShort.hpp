// standard/bits/DD_IsUnsignedShort.hpp
#ifndef _DD_IS_UNSIGNED_SHORT_HPP
#	define _DD_IS_UNSIGNED_SHORT_HPP 1



#	if __cplusplus >= 201103L
#		include "DD_And.hpp"
#	else
#		include "DD_IntegralConstant.hpp"
#	endif
#	include "DD_RemoveCV.hpp"



DD_DETAIL_BEGIN
template <typename ObjectT>
struct _IsUnsignedShort : FalseType {
};



template <>
struct _IsUnsignedShort<unsigned short> : TrueType {
};



DD_DETAIL_END



DD_BEGIN
#	if __cplusplus >= 201103L
template <typename... ObjectsT>
using IsUnsignedShort = AndType<detail::_IsUnsignedShort<RemoveCVType<ObjectsT>>...>;
#	else
template <typename ObjectT>
struct IsUnsignedShort : detail::_IsUnsignedShort<typename RemoveCV<ObjectT>::Type> {
};
#	endif



DD_END



#endif
