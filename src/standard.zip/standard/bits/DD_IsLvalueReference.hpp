// standard/bits/DD_IsLvalueReference.hpp
#ifndef _DD_IS_LVALUE_REFERENCE_HPP
#	define _DD_IS_LVALUE_REFERENCE_HPP 1



#	if __cplusplus < 201103L
#		error ISO/IEC 14882:2011 or a later version support is required for'DD::IsLvalueReference'.
#	endif



#	include <type_traits>

#	include "DD_And.hpp"



DD_DETAIL_BEGIN
template <typename ObjectT>
struct _IsLvalueReference : StdBoolConstant<std::is_lvalue_reference<ObjectT>> {
};



template <typename ObjectT>
struct _IsLvalueReference<ObjectT&> : TrueType {
};



DD_DETAIL_END



DD_BEGIN
template <typename... ObjectsT>
using IsLvalueReference = AndType<detail::_IsLvalueReference<ObjectsT>...>;



DD_END



#endif
