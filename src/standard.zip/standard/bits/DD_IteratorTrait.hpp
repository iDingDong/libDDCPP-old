// standard/bits/DD_IteratorTrait.hpp
#ifndef _DD_ITERATOR_TRAIT_HPP
#	define _DD_ITERATOR_TRAIT_HPP 1



#	include "DD_Trait.hpp"
#	include "DD_IteratorReverse.hpp"
#	include "DD_IsUndirectionalIterator.hpp"
#	include "DD_IsBidirectionalIterator.hpp"
#	include "DD_IsFreeAccessIterator.hpp"



DD_BEGIN
template <typename IteratorT>
struct IteratorTrait : Trait<IteratorT> {
	DD_ALIAS(IteratorType, IteratorT);
	
	DD_ALIAS(IsUndiretionalIterator, DD::IsUndirectionalIterator<IteratorType>)
	DD_ALIAS(IsBidiretionalIterator, DD::IsBidirectionalIterator<IteratorType>)
	DD_ALIAS(IsFreeAccessIterator, DD::IsFreeAccessIterator<IteratorType>)
	
	DD_ALIAS(ValueType, typename IteratorValue<IteratorType>::Type)
	DD_ALIAS(ReferenceType, typename IteratorReference<IteratorType>::Type)
	DD_ALIAS(PointerType, typename IteratorPointer<IteratorType>::Type)
	DD_ALIAS(DifferenceType, typename IteratorDifference<IteratorType>::Type)
	DD_ALIAS(CatagoryType, typename IteratorCatagory<IteratorType>::Type)
	DD_ALIAS(ReverseType, typename IteratorReverse<IteratorType>::Type)
	
	
};



DD_END



#endif