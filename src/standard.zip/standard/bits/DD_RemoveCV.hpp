// standard/bits/DD_RemoveCV.hpp
#ifndef _DD_REMOVE_C_V_HPP
#	define _DD_REMOVE_C_V_HPP 1



#	include "DD_RemoveConst.hpp"
#	include "DD_RemoveVolatile.hpp"



DD_BEGIN
#	if __cplusplus >= 201103L
template <typename ObjectT>
using RemoveCV = RemoveVolatile<RemoveConstType<ObjectT>>;
template <typename ObjectT>
using RemoveCVType = typename RemoveCV<ObjectT>::Type;
#	else
template <typename ObjectT>
struct RemoveCV : RemoveVolatile<typename RemoveConst<ObjectT>::Type> {
};
#	endif



DD_END



#endif