// standard/bits/DD_Or.hpp
#ifndef _DD_OR_HPP
#	define _DD_OR_HPP 1



#	include "DD_IntegralConstant.hpp"



#	if __cplusplus >= 201103L
DD_DETAIL_BEGIN
template <typename... ContidionsT>
struct _Or : FalseType {
};



template <typename ConditionT1, typename ConditionT2, typename... ConditionsT>
struct _Or<ConditionT1, ConditionT2, ConditionsT...> : _Or<ConditionT1, _Or<ConditionT2, ConditionsT...>> {
};



template <typename ConditionT1, typename ConditionT2>
struct _Or<ConditionT1, ConditionT2> : BoolConstant<ConditionT1::value || ConditionT2::value> {
};



template <typename ConditionT>
struct _Or<ConditionT> : BoolConstant<ConditionT::value> {
};



DD_DETAIL_END



#	endif
DD_BEGIN
#	if __cplusplus >= 201103L
template <typename... ConditionsT>
using Or = detail::_Or<ConditionsT...>;
template <typename... ConditionsT>
using OrType = typename Or<ConditionsT...>::Type;
#	else
template <typename ConditionT1, typename ConditionT2>
struct Or : BoolConstant<ConditionT1::value && ConditionT2::value> {
};
#	endif



DD_END



#endif
