// standard/bits/DD_IsReference.hpp
#ifndef _DD_IS_REFERENCE_HPP
#	define _DD_IS_REFERENCE_HPP 1



#	if __cplusplus >= 201103L
#		include "DD_Or.hpp"
#		include "DD_IsLvalueReference.hpp"
#		include "DD_IsRvalueReference.hpp"
#	else
#		include "DD_IntegralConstant.hpp"
#	endif



DD_DETAIL_BEGIN
template <typename ObjectT>
#	if __cplusplus >= 201103L
using _IsReference = OrType<IsLvalueReference<ObjectT>, IsRvalueReference<ObjectT>>;
#	else
struct _IsReference : FalseType {
};



template <typename ObjectT>
struct _IsReference<ObjectT&> : TrueType {
};
#	endif



DD_DETAIL_END



DD_BEGIN
#	if __cplusplus >= 201103L
template <typename... ObjectsT>
using IsReference = AndType<detail::_IsReference<ObjectsT>...>;
#	else
template <typename ObjectT>
struct IsReference : detail::_IsReference<ObjectT> {
};
#	endif



DD_END



#endif
