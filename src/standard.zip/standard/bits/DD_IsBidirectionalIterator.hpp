// standard/bits/DD_IsBidirectionalIterator.hpp
#ifndef _DD_IS_BIDIRECTIONAL_ITERATOR_HPP
#	define _DD_IS_BIDIRECTIONAL_ITERATOR_HPP 1



#	include "DD_IsBaseOf.hpp"
#	include "DD_IteratorCatagory.hpp"



DD_BEGIN
#	if __cplusplus >= 201103L
template <typename... IteratorsT>
using IsBidirectionalIterator = IsBaseOf<BidirectionalIterator, IteratorCatagoryType<IteratorsT>...>;
#	else
template <typename IteratorT>
struct IsBidirectionalIterator : IsBaseOf<BidirectionalIterator, typename IteratorCatagory<IteratorT>::Type> {
};
#	endif



DD_END



#endif