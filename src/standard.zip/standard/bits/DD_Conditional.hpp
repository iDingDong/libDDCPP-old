// standard/bits/DD_Conditional.hpp
#ifndef _DD_CONDITIONAL_HPP
#	define _DD_CONDITIONAL_HPP 1



#	include "DD_global_definitions.hpp"



DD_DETAIL_BEGIN
template <ValidityType condition_c, typename ThenT, typename ElseT>
struct _Conditional {
	DD_ALIAS(Type, ElseT)
	
	
};



template <typename ThenT, typename ElseT>
struct _Conditional<true, ThenT, ElseT> {
	DD_ALIAS(Type, ThenT)
	
	
};



DD_DETAIL_END



DD_BEGIN
#	if __cplusplus >= 201103L
template <ValidityType condition_c, typename ThenT, typename ElseT>
using Conditional = detail::_Conditional<condition_c, ThenT, ElseT>;
template <ValidityType condition_c, typename ThenT, typename ElseT>
using ConditionalType = typename Conditional<condition_c, ThenT, ElseT>::Type;
#	else
template <ValidityType condition_c, typename ThenT, typename ElseT>
struct Conditional : detail::_Conditional<condition_c, ThenT, ElseT> {
};
#	endif



DD_END



#endif
