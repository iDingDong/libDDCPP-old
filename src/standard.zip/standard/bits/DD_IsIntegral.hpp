// standard/bits/DD_IsIntegral.hpp
#ifndef _DD_IS_INTEGRAL_HPP
#	define _DD_IS_INTEGRAL_HPP 1



#	if __cplusplus > 201103L
#		include <type_traits>
#	endif

#	include "DD_IsBool.hpp"

#	include "DD_IsCharactor.hpp"

#	include "DD_IsUnsignedShort.hpp"
#	include "DD_IsSignedShort.hpp"
#	include "DD_IsUnsignedInt.hpp"
#	include "DD_IsSignedInt.hpp"
#	include "DD_IsUnsignedLong.hpp"
#	include "DD_IsSignedLong.hpp"
#	if __cplusplus >= 201103L
#		include "DD_IsUnsignedLongLong.hpp"
#		include "DD_IsSignedLongLong.hpp"
#	endif



#	if __cplusplus >= 201103L
DD_DETAIL_BEGIN
template <typename ObjectT>
using _IsIntegral = OrType<
	IsBool<ObjectT>,
	IsCharactor<ObjectT>,
	IsUnsignedShort<ObjectT>,
	IsSignedShort<ObjectT>,
	IsUnsignedInt<ObjectT>,
	IsSignedInt<ObjectT>,
	IsUnsignedLong<ObjectT>,
	IsSignedLong<ObjectT>,
	IsUnsignedLongLong<ObjectT>,
	IsSignedLongLong<ObjectT>,
	StdBoolConstant<std::is_integral<ObjectT>>
>;



DD_DETAIL_END



#	endif
DD_BEGIN
#	if __cplusplus >= 201103L
template <typename... ObjectsT>
using IsIntegral = AndType<detail::_IsIntegral<ObjectsT>...>;
#	else
template <typename ObjectT>
struct IsIntegral : BoolConstant<
	IsBool<ObjectT>::value ||
	IsCharactor<ObjectT>::value ||
	IsUnsignedShort<ObjectT>::value ||
	IsSignedShort<ObjectT>::value ||
	IsUnsignedInt<ObjectT>::value ||
	IsSignedInt<ObjectT>::value ||
	IsUnsignedLong<ObjectT>::value ||
	IsSignedLong<ObjectT>::value
> {
};
#	endif



DD_END



#endif
