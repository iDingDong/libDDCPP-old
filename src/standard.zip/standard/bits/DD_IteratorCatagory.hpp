// standard/bits/DD_IteratorCatagory.hpp
#ifndef _DD_ITERATOR_CATAGORY_HPP
#	define _DD_ITERATOR_CATAGORY_HPP



#	include "DD_RemoveCV.hpp"



DD_DETAIL_BEGIN
struct _FixedIterator {
};



struct _UndirectionalIterator : _FixedIterator {
};



struct _BidirectionalIterator : _UndirectionalIterator {
};



struct _FreeAccessIterator : _BidirectionalIterator {
};



template <typename IteratorT>
struct _IteratorCatagory {
	DD_ALIAS(Type, typename IteratorT::CatagoryType)
	
	
};



template <typename ValueT>
struct _IteratorCatagory<ValueT*> {
	DD_ALIAS(Type, _FreeAccessIterator)
	
	
};



DD_DETAIL_END



DD_BEGIN
DD_ALIAS(FixedIterator, detail::_FixedIterator)
DD_ALIAS(UndirectionalIterator, detail::_UndirectionalIterator)
DD_ALIAS(BidirectionalIterator, detail::_BidirectionalIterator)
DD_ALIAS(FreeAccessIterator, detail::_FreeAccessIterator)



template <typename IteratorT>
#	if __cplusplus >= 201103L
using IteratorCatagory = detail::_IteratorCatagory<RemoveCVType<IteratorT>>;
template <typename IteratorT>
using IteratorCatagoryType = typename IteratorCatagory<IteratorT>::Type;
#	else
struct IteratorCatagory : detail::_IteratorCatagory<IteratorT> {
};
#	endif



DD_END



#endif