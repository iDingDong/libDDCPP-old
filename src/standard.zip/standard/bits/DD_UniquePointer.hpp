// standard/bits/DD_UniquePointer.hpp
#ifndef _DD_UNIQUE_POINTER_HPP
#	define _DD_UNIQUE_POINTER_HPP 1



#	if __cplusplus >= 201103L
#		include "DD_forward.hpp"
#	endif
#	include "DD_Allocator.hpp"
#	include "DD_swap.hpp"



DD_BEGIN
template <typename ValueT, typename DeleterT = void>
struct UniquePointer {
	public:
#	if __cplusplus >= 201103L
	using ThisType = UniquePointer<ValueT, DeleterT>;
#	else
	typedef UniquePointer<ValueT, DeleterT> ThisType;
#	endif
	DD_ALIAS(ValueType, ValueT)
	DD_ALIAS(DeleterType, DeleterT)
	
	public:
	DD_ALIAS(PointerType, ValueType*)
	DD_ALIAS(ReferenceType, ValueType&)
	DD_ALIAS(DifferenceType, DD::DifferenceType)
	
	
	private:
#	if __cplusplus >= 201103L
	PointerType m_pointer = PointerType();
	DeleterType m_deleter = DeleterType();
#	else
	PointerType m_pointer;
	DeleterType m_deleter;
#	endif
	
	
#	if __cplusplus >= 201103L
	public:
	constexpr UniquePointer() = default;
	
	public:
	UniquePointer(ThisType const&) = delete;
	
	public:
	constexpr UniquePointer(ThisType&& origin) noexcept : m_pointer(origin.release()), m_deleter(forward<DeleterType>(origin.m_deleter)) {
	}
#	else
	public:
	UniquePointer() DD_NOEXCEPT : m_pointer(), m_deleter() {
	}
	
	private:
	UniquePointer(ThisType const&);// Deleted by undefined private declaration
#	endif
	
	public:
	explicit DD_CONSTEXPR UniquePointer(PointerType target) DD_NOEXCEPT : m_pointer(target) {
	}
	
#	if __cplusplus >= 201103L
	public:
	template <typename DeleterT_>
	constexpr UniquePointer(DeleterT_&& deleter) noexcept(noexcept(DeleterType(forward<DeleterT_>(deleter)))) : m_deleter(forward<DeleterT_>(deleter)) {
	}
	
	public:
	template <typename DeleterT_>
	constexpr UniquePointer(PointerType target, DeleterT_&& deleter) noexcept(noexcept(DeleterType(forward<DeleterT_>(deleter)))) : m_pointer(target), m_deleter(forward<DeleterT_>(deleter)) {
	}
#	else
	public:
	template <typename DeleterT_>
	UniquePointer(DeleterT_ const& deleter) : m_pointer(), m_deleter(deleter) {
	}
	
	public:
	template <typename DeleterT_>
	constexpr UniquePointer(PointerType target, DeleterT_ const& deleter) : m_pointer(target), m_deleter(deleter) {
	}
#	endif
	
	
	public:
	~UniquePointer() DD_NOEXCEPT {
		this->destroy();
	}
	
	
	public:
	ProcessType reset(PointerType target = PointerType()) DD_NOEXCEPT {
		this->destroy();
		this->m_pointer = target;
	}
	
	
	public:
	PointerType release() DD_NOEXCEPT {
#	if __cplusplus >= 201103L
		auto temp(this->m_pointer);
#	else
		PointerType temp(this->m_pointer);
#	endif
		this->m_pointer = PointerType();
		return temp;
	}
	
	
	public:
	ProcessType swap(ThisType& target) DD_NOEXCEPT {
		using DD::swap;
		swap(this->m_pointer, target.m_pointer);
		swap(this->m_deleter, target.m_deleter);
	}
	
	
	public:
	PointerType get_pointer() const DD_NOEXCEPT {
		return this->m_pointer;
	}
	
	
	private:
	ProcessType destroy() const DD_NOEXCEPT {
		this->m_deleter(this->m_pointer);
	}
	
	
#	if __cplusplus >= 201103L
	public:
	ThisType& operator =(ThisType const&) = delete;
	
	public:
	ThisType& operator =(ThisType&& origin) noexcept(true) {
		this->swap(origin);
	}
#	else
	private:
	ThisType& operator =(ThisType const&);
#	endif
	
	public:
	ThisType& operator =(PointerType target) DD_NOEXCEPT {
		this->reset(target);
	}
	
	
	public:
	ReferenceType operator *() const DD_NOEXCEPT {
		return *this->m_pointer;
	}
	
	
	public:
	PointerType operator ->() const DD_NOEXCEPT {
		return this->m_pointer;
	}
	
	
};



template <typename ValueT, ValidityType manage_pool>
struct UniquePointer<ValueT, Allocator<ValueT, manage_pool>> {
	public:
#	if __cplusplus >= 201103L
	using ThisType = UniquePointer<ValueT, Allocator<ValueT, manage_pool>>;
#	else
	typedef UniquePointer<ValueT, Allocator<ValueT, manage_pool>> ThisType;
#	endif
	DD_ALIAS(ValueType, ValueT)
	DD_ALIAS(DeleterType, Allocator<ValueT, manage_pool>)
	
	public:
	DD_ALIAS(PointerType, ValueType*)
	DD_ALIAS(ReferenceType, ValueType&)
	DD_ALIAS(DifferenceType, DD::DifferenceType)
	
	
	private:
#	if __cplusplus >= 201103L
	PointerType m_pointer = PointerType();
#	else
	PointerType m_pointer;
#	endif
	
	
	public:
#	if __cplusplus >= 201103L
	constexpr UniquePointer() = default;
	
	public:
	UniquePointer(ThisType const&) = delete;
	
	public:
	constexpr UniquePointer(ThisType&& origin) noexcept : m_pointer(origin.release()) {
	}
#	else
	UniquePointer() throw() : m_pointer() {
	}
	
	private:
	UniquePointer(ThisType const&);// Deleted by undefined private declaration
#	endif
	
	public:
	explicit DD_CONSTEXPR UniquePointer(PointerType target) DD_NOEXCEPT : m_pointer(target) {
	}
	
	
	public:
	~UniquePointer() DD_NOEXCEPT {
		this->destroy();
	}
	
	
	public:
	ProcessType reset(PointerType target = PointerType()) DD_NOEXCEPT {
		this->destroy();
		this->m_pointer = target;
	}
	
	
	public:
	PointerType release() DD_NOEXCEPT {
#	if __cplusplus >= 201103L
		auto temp(this->m_pointer);
#	else
		PointerType temp(this->m_pointer);
#	endif
		this->m_pointer = PointerType();
		return temp;
	}
	
	
	public:
	ProcessType swap(ThisType& target) DD_NOEXCEPT {
		using DD::swap;
		swap(this->m_pointer, target.m_pointer);
	}
	
	
	public:
	PointerType get_pointer() const DD_NOEXCEPT {
		return this->m_pointer;
	}
	
	
	private:
	ProcessType destroy() const DD_NOEXCEPT {
		DeleterType::destroy(m_pointer);
		DeleterType::deallocate(m_pointer);
	}
	
	
#	if __cplusplus >= 201103L
	public:
	ThisType& operator =(ThisType const&) = delete;
	
	public:
	ThisType& operator =(ThisType&& origin) noexcept(true) {
		this->swap(origin);
	}
#	else
	private:
	ThisType& operator =(ThisType const&);
#	endif
	
	public:
	ThisType& operator =(PointerType target) DD_NOEXCEPT {
		this->reset(target);
	}
	
	
	public:
	ReferenceType operator *() const DD_NOEXCEPT {
		return *this->m_pointer;
	}
	
	
	public:
	PointerType operator ->() const DD_NOEXCEPT {
		return this->m_pointer;
	}
	
	
};



template <typename ValueT>
struct UniquePointer<ValueT, void> {
	public:
#	if __cplusplus >= 201103L
	using ThisType = UniquePointer<ValueT, void>;
#	else
	typedef UniquePointer<ValueT, void> ThisType;
#	endif
	DD_ALIAS(ValueType, ValueT)
	DD_ALIAS(DeleterType, void)
	
	public:
	DD_ALIAS(PointerType, ValueType*)
	DD_ALIAS(ReferenceType, ValueType&)
	DD_ALIAS(DifferenceType, DD::DifferenceType)
	
	
	private:
#	if __cplusplus >= 201103L
	PointerType m_pointer = PointerType();
#	else
	PointerType m_pointer;
#	endif
	
	
	public:
#	if __cplusplus >= 201103L
	constexpr UniquePointer() = default;
	
	public:
	UniquePointer(ThisType const&) = delete;
	
	public:
	constexpr UniquePointer(ThisType&& origin) noexcept : m_pointer(origin.release()) {
	}
#	else
	UniquePointer() throw() : m_pointer() {
	}
	
	private:
	UniquePointer(ThisType const&);// Deleted by undefined private declaration
#	endif
	
	public:
	explicit DD_CONSTEXPR UniquePointer(PointerType target) DD_NOEXCEPT : m_pointer(target) {
	}
	
	
	public:
	~UniquePointer() DD_NOEXCEPT {
		this->destroy();
	}
	
	
	public:
	ProcessType reset(PointerType target = PointerType()) DD_NOEXCEPT {
		this->destroy();
		this->m_pointer = target;
	}
	
	
	public:
	PointerType release() DD_NOEXCEPT {
#	if __cplusplus >= 201103L
		auto temp(this->m_pointer);
#	else
		PointerType temp(this->m_pointer);
#	endif
		this->m_pointer = PointerType();
		return temp;
	}
	
	
	public:
	ProcessType swap(ThisType& target) DD_NOEXCEPT {
		using DD::swap;
		swap(this->m_pointer, target.m_pointer);
	}
	
	
	public:
	PointerType get_pointer() const DD_NOEXCEPT {
		return this->m_pointer;
	}
	
	
	private:
	ProcessType destroy() const DD_NOEXCEPT {
		DD_STATIC_ASSERT(sizeof(ValueType) > 0, "Cannot delete a pointer to an imcomplete type. ");
		delete this->m_pointer;
	}
	
	
#	if __cplusplus >= 201103L
	public:
	ThisType& operator =(ThisType const&) = delete;
	
	public:
	ThisType& operator =(ThisType&& origin) noexcept(true) {
		this->swap(origin);
	}
#	else
	private:
	ThisType& operator =(ThisType const&);
#	endif
	
	public:
	ThisType& operator =(PointerType target) DD_NOEXCEPT {
		this->reset(target);
	}
	
	
	public:
	ReferenceType operator *() const DD_NOEXCEPT {
		return *this->m_pointer;
	}
	
	
	public:
	PointerType operator ->() const DD_NOEXCEPT {
		return this->m_pointer;
	}
	
	
};



template <typename ValueT>
struct UniquePointer<ValueT[], void> {
	public:
#	if __cplusplus >= 201103L
	using ThisType = UniquePointer<ValueT, void>;
#	else
	typedef UniquePointer<ValueT, void> ThisType;
#	endif
	DD_ALIAS(ValueType, ValueT)
	DD_ALIAS(DeleterType, void)
	
	public:
	DD_ALIAS(PointerType, ValueType*)
	DD_ALIAS(ReferenceType, ValueType&)
	DD_ALIAS(DifferenceType, DD::DifferenceType)
	
	
	private:
#	if __cplusplus >= 201103L
	PointerType m_pointer = PointerType();
#	else
	PointerType m_pointer;
#	endif
	
	
	public:
#	if __cplusplus >= 201103L
	constexpr UniquePointer() = default;
	
	public:
	UniquePointer(ThisType const&) = delete;
	
	public:
	constexpr UniquePointer(ThisType&& origin) noexcept : m_pointer(origin.release()) {
	}
#	else
	UniquePointer() throw() : m_pointer() {
	}
	
	private:
	UniquePointer(ThisType const&);// Deleted by undefined private declaration
#	endif
	
	public:
	DD_CONSTEXPR UniquePointer(PointerType target) DD_NOEXCEPT : m_pointer(target) {
	}
	
	
	public:
	~UniquePointer() DD_NOEXCEPT {
		this->destroy();
	}
	
	
	public:
	ProcessType reset(PointerType target = PointerType()) DD_NOEXCEPT {
		this->destroy();
		this->m_pointer = target;
	}
	
	
	public:
	PointerType release() DD_NOEXCEPT {
#	if __cplusplus >= 201103L
		auto temp(this->m_pointer);
#	else
		PointerType temp(this->m_pointer);
#	endif
		this->m_pointer = PointerType();
		return temp;
	}
	
	
	public:
	ProcessType swap(ThisType& target) DD_NOEXCEPT {
		using DD::swap;
		swap(this->m_pointer, target.m_pointer);
	}
	
	
	public:
	PointerType get_pointer() const DD_NOEXCEPT {
		return this->m_pointer;
	}
	
	
	private:
	ProcessType destroy() const DD_NOEXCEPT {
		DD_STATIC_ASSERT(sizeof(ValueType) > 0, "Cannot delete a pointer to an imcomplete type. ");
		delete[] this->m_pointer;
	}
	
	
#	if __cplusplus >= 201103L
	public:
	ThisType& operator =(ThisType const&) = delete;
	
	public:
	ThisType& operator =(ThisType&& origin) noexcept {
		this->swap(origin);
	}
#	else
	private:
	ThisType& operator =(ThisType const&);
#	endif
	
	public:
	ThisType& operator =(PointerType target) DD_NOEXCEPT {
		this->reset(target);
	}
	
	
	public:
	ReferenceType operator *() const DD_NOEXCEPT {
		return *this->m_pointer;
	}
	
	
	public:
	PointerType operator ->() const DD_NOEXCEPT {
		return this->m_pointer;
	}
	
	
};



template <typename ValueT, typename DeleterT>
inline ProcessType swap(
	UniquePointer<ValueT, DeleterT>& unique_pointer_1, UniquePointer<ValueT, DeleterT>& unique_pointer_2
) DD_NOEXCEPT {
	unique_pointer_1.swap(unique_pointer_2);
}



DD_END



#endif