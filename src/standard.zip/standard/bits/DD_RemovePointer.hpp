// standard/bits/DD_RemovePointer.hpp
#ifndef _DD_REMOVE_POINTER_HPP
#	define _DD_REMOVE_POINTER_HPP 1



#	if __cplusplus >= 201103L
#		include <type_traits>
#	endif

#	include "DD_global_definitions.hpp"



DD_BEGIN
template <typename ObjectT>
struct RemovePointer {
#	if __cplusplus >= 201402L
	using Type = std::remove_pointer_t<ObjectT>;
#	elif __cplusplus >= 201103L
	using Type = typename std::remove_pointer<ObjectT>::type;
#	else
	typedef ObjectT Type;
#	endif
	
	
};



template <typename ObjectT>
struct RemovePointer<ObjectT*> {
	DD_ALIAS(Type, ObjectT)
	
	
};



template <typename ObjectT>
struct RemovePointer<ObjectT* const> {
	DD_ALIAS(Type, ObjectT)
	
	
};



template <typename ObjectT>
struct RemovePointer<ObjectT* volatile> {
	DD_ALIAS(Type, ObjectT)
	
	
};



template <typename ObjectT>
struct RemovePointer<ObjectT* const volatile> {
	DD_ALIAS(Type, ObjectT)
	
	
};



#	if __cplusplus >= 201103L
template <typename ObjectT>
using RemovePointerType = typename RemovePointer<ObjectT>::Type;



#	endif
DD_END



#endif