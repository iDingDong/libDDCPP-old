// standard/bits/DD_meta_definitions.hpp
#ifndef _DD_META_DEFINITIONS_HPP
#	define _DD_META_DEFINITIONS_HPP 1



#	define DD_MACRO_DETAIL_BEGIN namespace _MACRO_detail {
#	define DD_MACRO_DETAIL_END }



#endif
