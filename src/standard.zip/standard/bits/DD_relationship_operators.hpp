// standard/bits/DD_relationship_operators.hpp
#ifndef _DD_RELATIONSHIP_OPERATORS_HPP
#	define _DD_RELATIONSHIP_OPERATORS_HPP 1



#	include "DD_global_definitions.hpp"



DD_BEGIN
template <typename ObjectT>
ValidityType DD_CONSTEXPR operator !=(ObjectT const& object_1, ObjectT const& object_2) DD_NOEXCEPT_AS(object_1 == object_2) {
	return !(object_1 == object_2);
}


template <typename ObjectT>
ValidityType DD_CONSTEXPR operator <=(ObjectT const& object_1, ObjectT const& object_2) DD_NOEXCEPT_AS(object_1 < object_2) {
	return !(object_2 < object_1);
}


template <typename ObjectT>
ValidityType DD_CONSTEXPR operator >(ObjectT const& object_1, ObjectT const& object_2) DD_NOEXCEPT_AS(object_1 < object_2) {
	return object_2 < object_1;
}


template <typename ObjectT>
ValidityType DD_CONSTEXPR operator >=(ObjectT const& object_1, ObjectT const& object_2) DD_NOEXCEPT_AS(object_1 < object_2) {
	return !(object_1 < object_2);
}



DD_END



#endif
