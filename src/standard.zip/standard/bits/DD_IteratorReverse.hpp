// standard/bits/DD_IteratorReverse.hpp
#ifndef _DD_ITERATOR_REVERSE_HPP
#	define _DD_ITERATOR_REVERSE_HPP



#	include "DD_CompatStlIterator.hpp"
#	include "DD_NestedTypeCheck.hpp"
#	include "DD_Or.hpp"
#	include "DD_IsSame.hpp"
#	if __cplusplus >= 201103L
#		include "DD_move.hpp"
#	endif
#	include "DD_relationship_operators.hpp"
#	include "DD_IteratorReference.hpp"
#	include "DD_IteratorPointer.hpp"
#	include "DD_IteratorDifference.hpp"
#	include "DD_IteratorCatagory.hpp"
#	include "DD_address_of.hpp"



DD_DETAIL_BEGIN
template <typename IteratorT>
struct _ReverseIterator {
	public:
	DD_ALIAS(ReverseType, IteratorT)
	DD_ALIAS(ThisType, _ReverseIterator<ReverseType>)
	
	public:
	DD_ALIAS(ValueType, typename IteratorValue<ReverseType>::Type)
	DD_ALIAS(ReferenceType, typename IteratorReference<ReverseType>::Type)
	DD_ALIAS(PointerType, typename IteratorPointer<ReverseType>::Type)
	DD_ALIAS(DifferenceType, typename IteratorDifference<ReverseType>::Type)
	DD_ALIAS(CatagoryType, typename IteratorCatagory<ReverseType>::Type)
	DD_COMPAT_STL_ITERATOR
	
	
	private:
#	if __cplusplus >= 201103L
	ReverseType m_iterator = ReverseType();
#	else
	ReverseType m_iterator;
#	endif
	
	
	public:
#	if __cplusplus >= 201103L
	DD_CONSTEXPR _ReverseIterator() DD_NOEXCEPT_AS(ReverseType()) = default;
	
	public:
	DD_CONSTEXPR _ReverseIterator(ThisType const& origin) DD_NOEXCEPT_AS(ReverseType(origin.m_iterator)) = default;
	
	public:
	DD_CONSTEXPR _ReverseIterator(ThisType&& origin) DD_NOEXCEPT_AS(ReverseType(move(origin.m_iterator))) : m_iterator(move(origin.m_iterator)) {
	}
#	else
	_ReverseIterator() : m_iterator() {
	}
#	endif
	
	public:
	DD_CONSTEXPR _ReverseIterator(ReverseType const& iterator) DD_NOEXCEPT_AS(ReverseType(iterator)) : m_iterator(iterator) {
	}
	
	public:
#	if __cplusplus >= 201103L
	template <typename... ArgumentsT>
	DD_CONSTEXPR _ReverseIterator(ArgumentsT const&... arguments) DD_NOEXCEPT_AS(ReverseType(arguments...)) : m_iterator(arguments...) {
#	else
	template <typename ArgumentT>
	DD_CONSTEXPR _ReverseIterator(ArgumentT const& argument) DD_NOEXCEPT_AS(ReverseType(argument)) : m_iterator(argument) {
#	endif
	}// Global reference doesn't work here. See test2.cpp
	
	
#	if __cplusplus >= 201103L
	public:
	~_ReverseIterator() noexcept(noexcept(m_iterator.~ReverseType())) = default;
	
	
#	endif
	public:
	ValidityType DD_CONSTEXPR equal(ThisType const& target) const DD_NOEXCEPT_AS(m_iterator == target.m_iterator) {
		return this->m_iterator == target.m_iterator;
	}
	
	
	public:
	ValidityType DD_CONSTEXPR less(ThisType const& target) const DD_NOEXCEPT_AS(target.m_iterator < m_iterator) {
		return target.m_iterator < this->m_iterator;
	}
	
	
	public:
	DifferenceType DD_CONSTEXPR difference(ThisType const& target) const DD_NOEXCEPT_AS(target.m_iterator - m_iterator) {
		return target.m_iterator - this->m_iterator;
	}
	
	
	public:
	PointerType DD_CONSTEXPR get_pointer() const DD_NOEXCEPT_AS(m_iterator.get_pointer()) {
		return address_of(*this->m_iterator);
	}
	
	
	public:
	ReverseType DD_CONSTEXPR reverse() const DD_NOEXCEPT_AS(ReverseType(m_iterator)) {
		return m_iterator;
	}
	
	

#	if __cplusplus >= 201103L
	public:
	ThisType& operator =(ThisType const& origin) DD_NOEXCEPT_AS(m_iterator = origin.m_iterator) = default;
	
	public:
	ThisType& operator =(ThisType&& origin) DD_NOEXCEPT_AS(m_iterator = move(origin.m_iterator)) {
		this->m_iterator = move(origin.m_iterator);
	}
	
#	endif
	public:
	ThisType& operator =(ReverseType const& iterator) DD_NOEXCEPT_AS(m_iterator = iterator) {
		this->m_iterator = iterator;
	}
	
#	if __cplusplus >= 201103L
	public:
	ThisType& operator =(ReverseType&& iterator) DD_NOEXCEPT_AS(m_iterator = move(iterator)) {
		this->m_iterator = move(iterator);
	}
	
#	endif
	public:
	template <typename ArgumentT>
	ThisType& operator =(ArgumentT const& argument) DD_NOEXCEPT_AS(m_iterator = argument) {
		this->m_iterator = argument;
	}// Global reference doesn't work here. See test2.cpp
	
	
	public:
	ThisType& operator ++() DD_NOEXCEPT_AS(--m_iterator) {
		--this->m_iterator;
		return *this;
	}
	
	public:
	ThisType operator ++(int) DD_NOEXCEPT_AS(m_iterator--) {
		return ThisType(m_iterator--);
	}
	
	
	public:
	ThisType& operator --() DD_NOEXCEPT_AS(++m_iterator) {
		++this->m_iterator;
		return *this;
	}
	
	public:
	ThisType operator --(int) DD_NOEXCEPT_AS(m_iterator++) {
		return ThisType(m_iterator++);
	}
	
	
	public:
	ThisType& operator +=(DifferenceType step) DD_NOEXCEPT_AS(m_iterator -= step) {
		this->m_iterator -= step;
		return *this;
	}
	
	
	public:
	ThisType& operator -=(DifferenceType step) DD_NOEXCEPT_AS(m_iterator += step) {
		this->m_iterator += step;
		return *this;
	}
	
	
	public:
	ReferenceType operator [](DifferenceType index) const DD_NOEXCEPT_AS(m_iterator[-index]) {
		return this->m_iterator[-index];
	}
	
	
	public:
	ReferenceType operator *() const DD_NOEXCEPT_AS(*m_iterator) {
		return *this->m_iterator;
	}
	
	
	public:
	PointerType operator ->() const DD_NOEXCEPT_AS(get_pointer) {
		return this->get_pointer();
	}
	
	
};



template <typename IteratorT>
inline ValidityType DD_CONSTEXPR operator ==(
	_ReverseIterator<IteratorT> const& _reverse_iterator_1,
	_ReverseIterator<IteratorT> const& _reverse_iterator_2
) DD_NOEXCEPT_AS(_reverse_iterator_1.equal(_reverse_iterator_2)) {
	return _reverse_iterator_1.equal(_reverse_iterator_2);
}


template <typename IteratorT>
inline ValidityType DD_CONSTEXPR operator <(
	_ReverseIterator<IteratorT> const& _reverse_iterator_1,
	_ReverseIterator<IteratorT> const& _reverse_iterator_2
) DD_NOEXCEPT_AS(_reverse_iterator_1.less(_reverse_iterator_2)) {
	return _reverse_iterator_1.less(_reverse_iterator_2);
}



DD_DETAIL_END



DD_BEGIN
DD_NESTED_TYPE_TRAIT(IteratorReverse, ReverseType, detail::_ReverseIterator<_MACRO_ObjectT>)



#	if __cplusplus >= 201103L
template <typename IteratorT>
using IteratorReverseType = typename IteratorReverse<IteratorT>::Type;



#	endif
DD_END



#endif