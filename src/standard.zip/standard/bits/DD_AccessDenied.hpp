// standard/bits/DD_AccessDenied.hpp
#ifndef _DD_ACCESS_DENIED_HPP
#	define _DD_ACCESS_DENIED_HPP 1



#	include "DD_Exception.hpp"



DD_BEGIN
struct AccessDenied : Exception {
#	if __cplusplus >= 201103L
	public:
	DD_CONSTEXPR AccessDenied() DD_NOEXCEPT = default;
	
	public:
	DD_CONSTEXPR AccessDenied(AccessDenied const& origin) DD_NOEXCEPT = default;
	
#	endif
	public:
	DD_CONSTEXPR AccessDenied(PromptType prompt) DD_NOEXCEPT : Exception(prompt) {
	}
	
	
#	if __cplusplus >= 201103L
	public:
	~AccessDenied() DD_NOEXCEPT override = default;
	
	
	public:
	AccessDenied& operator =(AccessDenied const& origin) noexcept(true) = default;
	
	
#	endif
};



DD_END



#endif 
