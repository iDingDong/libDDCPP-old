// standard/bits/DD_IsUnsignedInt.hpp
#ifndef _DD_IS_UNSIGNED_INT_HPP
#	define _DD_IS_UNSIGNED_INT_HPP 1



#	if __cplusplus >= 201103L
#		include "DD_And.hpp"
#	else
#		include "DD_IntegralConstant.hpp"
#	endif
#	include "DD_RemoveCV.hpp"



DD_DETAIL_BEGIN
template <typename ObjectT>
struct _IsUnsignedInt : FalseType {
};



template <>
struct _IsUnsignedInt<unsigned int> : TrueType {
};



DD_DETAIL_END



DD_BEGIN
#	if __cplusplus >= 201103L
template <typename... ObjectsT>
using IsUnsignedInt = AndType<detail::_IsUnsignedInt<RemoveCVType<ObjectsT>>...>;
#	else
template <typename ObjectT>
struct IsUnsignedInt : detail::_IsUnsignedInt<typename RemoveCV<ObjectT>::Type> {
};
#	endif



DD_END



#endif
