// standard/bits/DD_IsClass.hpp
#ifndef _DD_IS_CLASS_HPP
#	define _DD_IS_CLASS_HPP 1



#	if __cplusplus >= 201103L
#		include <type_traits>

#		include "DD_Nil.hpp"
#		include "DD_And.hpp"
#	else
#		include "DD_SizeTrait.hpp"
#		include "DD_IntegralConstant.hpp"
#	endif



DD_DETAIL_BEGIN
template <typename ObjectT>
struct _IsClassMatcher {
#	if __cplusplus >= 201103L
	template <typename ObjectT_>
	static ValidityType DD_CONSTEXPR match(int ObjectT_::*) DD_NOEXCEPT {
		return true;
	}
	
	template <typename ObjectT_>
	static ValidityType DD_CONSTEXPR match(...) DD_NOEXCEPT {
		return false;
	}
	
	
	static ValidityType DD_CONSTANT value = match<ObjectT>(nil_pointer) || std::is_class<ObjectT>::value;
#	else
	template <typename ObjectT_>
	static SizeTrait<1> match(int ObjectT_::*) DD_NOEXCEPT;
	
	template <typename ObjectT_>
	static SizeTrait<2> match(...) DD_NOEXCEPT;
	
	
	static ValidityType DD_CONSTANT value = sizeof(match<ObjectT>(0)) == sizeof(SizeTrait<1>);
#	endif
	
	
};



DD_DETAIL_END



DD_BEGIN
#	if __cplusplus >= 201103L
template <typename... ObjectsT>
using IsClass = AndType<BoolConstant<detail::_IsClassMatcher<ObjectsT>::value>...>;
#	else
template <typename ObjectT>
struct IsClass : BoolConstant<detail::_IsClassMatcher<ObjectT>::value> {
};
#	endif



DD_END



#endif