// standard/bits/DD_IsCharactor.hpp
#ifndef _DD_IS_CHARACTOR_HPP
#	define _DD_IS_CHARACTOR_HPP 1




#	if __cplusplus >= 201103L
#		include "DD_Or.hpp"
#	endif

#	include "DD_IsUnsignedChar.hpp"
#	include "DD_IsSignedChar.hpp"
#	include "DD_IsChar.hpp"
#	include "DD_IsWChar.hpp"
#	if __cplusplus >= 201103L
#		include "DD_IsChar16.hpp"
#		include "DD_IsChar32.hpp"
#	endif



#	if __cplusplus >= 201103L
DD_DETAIL_BEGIN
template <typename ObjectT>
using _IsCharactor = OrType<
	IsUnsignedChar<ObjectT>,
	IsSignedChar<ObjectT>,
	IsChar<ObjectT>,
	IsWChar<ObjectT>,
	IsChar16<ObjectT>,
	IsChar32<ObjectT>
>;



DD_DETAIL_END



#	endif
DD_BEGIN
#	if __cplusplus >= 201103L
template <typename... ObjectsT>
using IsCharactor = AndType<detail::_IsCharactor<ObjectsT>...>;
#	else
template <typename ObjectT>
struct IsCharactor : BoolConstant<
	IsUnsignedChar<ObjectT>::value ||
	IsSignedChar<ObjectT>::value ||
	IsChar<ObjectT>::value ||
	IsWChar<ObjectT>::value
> {
};
#	endif



DD_END



#endif
