// standard/bits/DD_IteratorDifference.hpp
#ifndef _DD_ITERATOR_DIFFERENCE_HPP
#	define _DD_ITERATOR_DIFFERENCE_HPP 1



#	include "DD_NestedTypeCheck.hpp"



DD_BEGIN
DD_NESTED_TYPE_TRAIT(IteratorDifference, DifferenceType, DD::DifferenceType)



#	if __cplusplus >= 201103L
template <typename IteratorT>
using IteratorDifferenceType = typename IteratorDifference<IteratorT>::Type;



#	endif
DD_END



#endif
