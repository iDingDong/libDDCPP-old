// standard/bits/DD_Allocator.hpp
#ifndef _DD_ALLOCATOR_HPP
#	define _DD_ALLOCATOR_HPP 1



#	include <cstdlib>

#	include "DD_AllocationFailure.hpp"
#	include "DD_address_of.hpp"



DD_BEGIN
template <typename ValueT, ValidityType manage_pool_c = true>
class Allocator {
	public:
#	if __cplusplus >= 201103L
	using ThisType = Allocator<ValueT, manage_pool_c>;
#	else
	typedef Allocator<ValueT, manage_pool_c> ThisType;
#	endif
	DD_ALIAS(ValueType, ValueT)
	
	DD_ALIAS(ReferenceType, ValueType&)
	DD_ALIAS(ConstReferenceType, ValueType const&)
	DD_ALIAS(PointerType, ValueType*)
	DD_ALIAS(ConstPointerType, ValueType const*)
	DD_ALIAS(LengthType, DD::LengthType)
	static SizeType DD_CONSTANT size_constant = sizeof(ValueType);
	
	public:
#	if __cplusplus >= 201103L
	using HandlerType = ProcessType();
#	else
	typedef ProcessType HandlerType();
#	endif
	
	
	public:
	static PointerType address(ReferenceType target) DD_NOEXCEPT {
		return address_of(target);
	}
	
	public:
	static ConstPointerType address(ConstReferenceType target) DD_NOEXCEPT {
		return address_of(target);
	}
	
	
	public:
	static PointerType allocate(LengthType length) DD_NOEXCEPT_IF(false) {
		SizeType size = size_constant * length;
		PointerType temp = reinterpret_cast<PointerType>(std::malloc(size));
		return temp ? temp : ThisType::failure_process(size);
	}
	
	
	public:
	template <typename IteratorT_>
	ProcessType deallocate(IteratorT_ const& target) DD_NOEXCEPT {
		std::free(address_of(*target));
	}
	
	
#	if __cplusplus >= 201103L
	public:
	template <typename IteratorT_, typename... ArgumentsT>
	ProcessType construct(PointerType target, ArgumentsT&&... arguments) noexcept(noexcept(ValueType(arguments...))) {
		new (address_of(*target)) ValueType(arguments...);
	}
	
	
#	endif
	public:
	template <typename IteratorT_>
	ProcessType destroy(IteratorT_ const& target) DD_NOEXCEPT_AS(target->~ValueType()) {
		target->~ValueType();
	}
	
	
	public:
	static HandlerType* set_handler(HandlerType* handler) DD_NOEXCEPT {
		HandlerType* temp = ThisType::m_handler;
		ThisType::m_handler = handler;
		return temp;
	}
	
	
	private:
	static PointerType failure_process(SizeType size) DD_NOEXCEPT_IF(false);
	
	
	private:
	static HandlerType* m_handler;
	
	
};



template <typename ValueT, ValidityType manage_pool>
typename Allocator<ValueT, manage_pool>::HandlerType* Allocator<ValueT, manage_pool>::m_handler = Allocator<ValueT>::HandlerType();



template <typename ValueT, ValidityType manage_pool>
typename Allocator<ValueT, manage_pool>::PointerType Allocator<ValueT, manage_pool>::failure_process(SizeType size) DD_NOEXCEPT_IF(false) {
	PointerType temp;
	do {
		if (!ThisType::m_handler) {
			throw AllocationFailure("Failed to allocate. ");
		}
		ThisType::m_handler();
		temp = reinterpret_cast<PointerType>(std::malloc(size));
	} while (!temp);
	return temp;
}



template <typename ValueT>
class Allocator<ValueT, true> : public Allocator<ValueT, false> {
};// Bad realization



DD_END



#endif