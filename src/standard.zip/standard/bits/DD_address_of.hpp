// standard/bits/DD_address_of.hpp
#ifndef _DD_ADDRESS_OF_HPP
#	define _DD_ADDRESS_OF_HPP 1



#	include "DD_global_definitions.hpp"



DD_BEGIN
template <typename ValueT>
ValueT* address_of(ValueT& target) DD_NOEXCEPT {
	return reinterpret_cast<ValueT*>(&const_cast<char&>(reinterpret_cast<char const volatile&>(target)));
}



DD_END



#endif