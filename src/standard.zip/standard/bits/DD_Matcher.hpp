// standard/bits/DD_Matcher.hpp
#ifndef _DD_MATCHER_HPP
#	define _DD_MATCHER_HPP



#	include "DD_global_definitions.hpp"



DD_BEGIN
template <typename ObjectT>
struct Matcher {
};



DD_END



#endif
