// standard/bits/DD_Trait.hpp
#ifndef _DD_TRAIT_HPP
#	define _DD_TRAIT_HPP 1



#	include "DD_IsVoid.hpp"
#	include "DD_IsIntegral.hpp"
#	include "DD_IsReference.hpp"
#	include "DD_IsPointer.hpp"
#	include "DD_IsArray.hpp"
#	if __cplusplus >= 201103L
#		include "DD_IsFunction.hpp"
#	endif
#	include "DD_IsClass.hpp"
#	include "DD_IsConst.hpp"
#	include "DD_IsVolatile.hpp"
#	include "DD_IsSame.hpp"
#	include "DD_IsBaseOf.hpp"
#	if __cplusplus >= 201103L
#		include "DD_IsNoexceptMoveConstructible.hpp"
#		include "DD_IsNoexceptMoveAssignable.hpp"
#	endif
#	include "DD_AddCV.hpp"
#	include "DD_RemoveReference.hpp"
#	include "DD_RemovePointer.hpp"
#	include "DD_RemoveExtent.hpp"
#	include "DD_RemoveAllExtents.hpp"



DD_BEGIN
template <typename ObjectT>
struct Trait {
	DD_ALIAS(ObjectType, ObjectT)
	
	DD_ALIAS(IsVoid, DD::IsVoid<ObjectType>)
	DD_ALIAS(IsBool, DD::IsBool<ObjectType>)
	DD_ALIAS(IsUnsignedChar, DD::IsUnsignedChar<ObjectType>)
	DD_ALIAS(IsSignedChar, DD::IsSignedChar<ObjectType>)
	DD_ALIAS(IsChar, DD::IsChar<ObjectType>)
	DD_ALIAS(IsWChar, DD::IsWChar<ObjectType>)
#	if __cplusplus >= 201103L
	DD_ALIAS(IsChar16, DD::IsChar16<ObjectType>)
	DD_ALIAS(IsChar32, DD::IsChar32<ObjectType>)
#	endif
	DD_ALIAS(IsCharactor, DD::IsCharactor<ObjectType>)
	DD_ALIAS(IsUnsignedShort, DD::IsUnsignedShort<ObjectType>)
	DD_ALIAS(IsSignedShort, DD::IsSignedShort<ObjectType>)
	DD_ALIAS(IsUnsignedInt, DD::IsUnsignedInt<ObjectType>)
	DD_ALIAS(IsSignedInt, DD::IsSignedInt<ObjectType>)
	DD_ALIAS(IsUnsignedLong, DD::IsUnsignedLong<ObjectType>)
	DD_ALIAS(IsSignedLong, DD::IsSignedLong<ObjectType>)
#	if __cplusplus >= 201103L
	DD_ALIAS(IsUnsignedLongLong, DD::IsUnsignedLongLong<ObjectType>)
	DD_ALIAS(IsSignedLongLong, DD::IsSignedLongLong<ObjectType>)
#	endif
	DD_ALIAS(IsIntegral, DD::IsIntegral<ObjectType>)
	DD_ALIAS(IsFunction, DD::IsFunction<ObjectType>)
#	if __cplusplus >= 201103L
	DD_ALIAS(IsLvalueReference, DD::IsLvalueReference<ObjectType>)
	DD_ALIAS(IsRvalueReference, DD::IsRvalueReference<ObjectType>)
#	endif
	DD_ALIAS(IsReference, DD::IsReference<ObjectType>)
	DD_ALIAS(IsPointer, DD::IsPointer<ObjectType>)
	DD_ALIAS(IsArray, DD::IsArray<ObjectType>)
	DD_ALIAS(IsClass, DD::IsClass<ObjectType>)
	DD_ALIAS(IsConst, DD::IsConst<ObjectType>)
	DD_ALIAS(IsVolatile, DD::IsVolatile<ObjectType>)
#	if __cplusplus >= 201103L
	DD_ALIAS(IsNoexceptMoveConstructible, DD::IsNoexceptMoveConstructible<ObjectType>)
	DD_ALIAS(IsNoexceptMoveAssignable, DD::IsNoexceptMoveAssignable<ObjectType>)
#	endif
#	if __cplusplus >= 201103L
	template <typename... ObjectsT_>
	using IsSame = DD::IsSame<ObjectType, ObjectsT_...>;
	template <typename... ObjectsT_>
	using IsBaseOf = DD::IsBaseOf<ObjectType, ObjectsT_...>;
#	else
	
	
	template <typename ObjectT_>
	struct IsSame : DD::IsSame<ObjectType, ObjectT_> {
	};
	
	
	template <typename ObjectT_>
	struct IsBaseOf = DD::IsBaseOf<ObjectType, ObjectT_> {
	};
	
#	endif
	
	DD_ALIAS(ConstAdded, typename AddConst<ObjectType>::Type)
	DD_ALIAS(VolatileAdded, typename AddVolatile<ObjectType>::Type)
	DD_ALIAS(CVAdded, typename AddCV<ObjectType>::Type)
	DD_ALIAS(ReferenceRemoved, typename RemoveReference<ObjectType>::Type)
	DD_ALIAS(PointerRemoved, typename RemovePointer<ObjectType>::Type)
	DD_ALIAS(ExtentRemoved, typename RemoveExtent<ObjectType>::Type)
	DD_ALIAS(AllExtentsRemoved, typename RemoveAllExtents<ObjectType>::Type)
	DD_ALIAS(ConstRemoved, typename RemoveConst<ObjectType>::Type)
	DD_ALIAS(VolatileRemoved, typename RemoveVolatile<ObjectType>::Type)
	DD_ALIAS(CVRemoved, typename RemoveCV<ObjectType>::Type)
	
	
};



DD_END



#endif