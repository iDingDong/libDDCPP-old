// standard/bits/DD_make_unique.hpp
#ifndef _DD_MAKE_UNIQUE_HPP
#	define _DD_MAKE_UNIQUE_HPP 1



#	if __cplusplus < 201103L
#		error ISO/IEC 14882:2011 or a later version support is required for'DD::make_unique'.



#	endif
#	include "DD_UniquePointer.hpp"



DD_BEGIN
template <typename ValueT, typename... ArgumentsT>
inline UniquePointer<ValueT, void> make_unique(
	ArgumentsT&&... construct_arguments
) DD_NOEXCEPT_AS(ValueT(construct_arguments...)) {
	return UniquePointer<ValueT, void>(new ValueT(construct_arguments...));
}



DD_END



#endif