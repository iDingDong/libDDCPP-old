// standard/bits/DD_IsUnsignedLongLong.hpp
#ifndef _DD_IS_UNSIGNED_LONG_LONG_HPP
#	define _DD_IS_UNSIGNED_LONG_LONG_HPP 1



#	if __cplusplus < 201103L
#		error ISO/IEC 14882:2011 or a later version support is required for'DD::IsUnsignedLongLong'.
#	endif



#	if __cplusplus >= 201103L
#		include "DD_And.hpp"
#	else
#		include "DD_IntegralConstant.hpp"
#	endif
#	include "DD_RemoveCV.hpp"



DD_DETAIL_BEGIN
template <typename ObjectT>
struct _IsUnsignedLongLong : FalseType {
};



template <>
struct _IsUnsignedLongLong<unsigned long long> : TrueType {
};



DD_DETAIL_END



DD_BEGIN
template <typename... ObjectsT>
using IsUnsignedLongLong = AndType<detail::_IsUnsignedLongLong<RemoveCVType<ObjectsT>>...>;



DD_END



#endif
