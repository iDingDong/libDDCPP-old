// standard/bits/DD_Nil.hpp
#ifndef _DD_NIL_HPP
#	define _DD_NIL_HPP 1



#	include "DD_relationship_operators.hpp"



DD_BEGIN
struct NilType {
};



struct NilPointerType {
#	if __cplusplus >= 201103L
	constexpr NilPointerType() noexcept(true) = default;
	
	constexpr NilPointerType(NilPointerType const&) = default;
	
	
#	endif
	template <typename ValueT_>
#	if __cplusplus >= 201103L
	constexpr operator ValueT_*() const noexcept(true) {
		return PointerType<ValueT_>();
#	else
	operator ValueT_*() const {
		typedef ValueT_* PointerType;
		return PointerType();
#	endif
	}
	
	
};



#	if __cplusplus >= 201103L
inline ValidityType constexpr operator ==(NilPointerType, NilPointerType) noexcept(true) {
#	else
inline ValidityType operator ==(NilPointerType, NilPointerType) throw() {
#	endif
	return true;
}



#	if __cplusplus >= 201103L
inline ValidityType constexpr operator <(NilPointerType, NilPointerType) noexcept(true) {
#	else
inline ValidityType operator <(NilPointerType, NilPointerType) throw() {
#	endif
	return false;
}



#	if __cplusplus >= 201103L
NilType constexpr nil;

NilPointerType constexpr nil_pointer;
#	else
NilType const nil;

NilPointerType const nil_pointer;
#	endif



DD_END



#endif
