// standard/bits/DD_IntegeralConstant.hpp
#ifndef _DD_INTERGRAL_CONSTANT_HPP
#	define _DD_INTERGRAL_CONSTANT_HPP 1



#	include "DD_global_definitions.hpp"



DD_BEGIN
template <typename ValueT, ValueT value_c>
struct IntegralConstant {
	DD_ALIAS(ValueType, ValueT)
	static ValueType DD_CONSTANT value = value_c;
	
#	if __cplusplus >= 201103L
	using Type = IntegralConstant<ValueType, value>;
	
	
	constexpr operator ValueType() const noexcept(true) {
		return value;
	}
#	else
	typedef IntegralConstant<ValueType, value> Type;
#	endif
	
	
};



template <bool value_c>
#	if __cplusplus >= 201103L
using BoolConstant = IntegralConstant<bool, value_c>;

template <DifferenceType difference_c>
using DifferenceConstant = IntegralConstant<DifferenceType, difference_c>;

template <typename IntegralT>
using StdIntegralConstant = IntegralConstant<typename IntegralT::value_type, IntegralT::value>;
template <typename IntegralT>
using StdBoolConstant = BoolConstant<IntegralT::value>;
#	else
struct BoolConstant : IntegralConstant<bool, value_c> {
};



template <DifferenceType difference_c>
struct DifferenceConstant : IntegralConstant<DifferenceType, difference_c> {
};



template <typename IntegralT>
struct StdIntegralConstant : IntegralConstant<typename IntegralT::value_type, IntegralT::value> {
};
#	endif



DD_ALIAS(TrueType, BoolConstant<true>)
DD_ALIAS(FalseType, BoolConstant<false>)



DD_END



#endif