// standard/bits/DD_And.hpp
#ifndef _DD_AND_HPP
#	define _DD_AND_HPP 1



#	include "DD_IntegralConstant.hpp"



#	if __cplusplus >= 201103L
DD_DETAIL_BEGIN
template <typename... ContidionsT>
struct _And : TrueType {
};



template <typename ConditionT1, typename ConditionT2, typename... ConditionsT>
struct _And<ConditionT1, ConditionT2, ConditionsT...> : _And<ConditionT1, _And<ConditionT2, ConditionsT...>> {
};



template <typename ConditionT1, typename ConditionT2>
struct _And<ConditionT1, ConditionT2> : BoolConstant<ConditionT1::value && ConditionT2::value> {
};



template <typename ConditionT>
struct _And<ConditionT> : BoolConstant<ConditionT::value> {
};



DD_DETAIL_END



#	endif
DD_BEGIN
#	if __cplusplus >= 201103L
template <typename... ConditionsT>
using And = detail::_And<ConditionsT...>;
template <typename... ConditionsT>
using AndType = typename And<ConditionsT...>::Type;
#	else
template <typename ConditionT1, typename ConditionT2>
struct And : BoolConstant<ConditionT1::value && ConditionT2::value> {
};
#	endif



DD_END



#endif
