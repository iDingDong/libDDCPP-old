// standard/bits/DDAlgorithm.hpp
#ifndef _DDALGORITHM_HPP
#	define _DDALGORITHM_HPP 1



#	include "bits/DD_insert_sort.hpp"
#	include "bits/DD_select_sort.hpp"



#endif