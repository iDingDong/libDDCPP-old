/***************************************************************
DDCPP
Version 1.000
standard


All but macro identifiers in this library are declared in
namespace DD. In addition, using some tools in DDMeta may add a
nested namespace _MACRO_detail in the current namespace.

Note1: DDCPP's reverse iterator behaves differently from STL
reverse iterators. A DDCPP's reverse iterator points to the same
element that the iterator it was initialized with points to.

***************************************************************/